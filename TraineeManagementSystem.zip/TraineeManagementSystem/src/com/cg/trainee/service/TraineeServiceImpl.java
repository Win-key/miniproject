package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	ITraineeDao dao;

	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		return dao.addTrainee(trainee);
	}

	@Override
	public TraineeBean findTrainee(int traineeId) {
		return dao.findTrainee(traineeId);
	}

	@Override
	public void deleteTrainee(int traineeId) {
		dao.deleteTrainee(traineeId);
	}

	@Override
	public List<TraineeBean> viewAllTrainees() {
		return dao.viewAllTrainees();
	}

	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
		return dao.modifyTrainee(traineeId, traineeName, traineeDomain, traineeLocation);
	
	}

	

	


}
