package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeDao {

	public TraineeBean addTrainee(TraineeBean trainee);

	public TraineeBean findTrainee(int traineeId);

	public void deleteTrainee(int traineeId);

	public List<TraineeBean> viewAllTrainees();

	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation);


	
}
