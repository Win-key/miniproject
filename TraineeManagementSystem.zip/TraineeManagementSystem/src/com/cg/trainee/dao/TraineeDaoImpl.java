package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public TraineeBean findTrainee(int traineeId) {

		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);
		return bean;
	}

	@Override
	public void deleteTrainee(int traineeId) {
		/*
		 * Query query=entityManager.createQuery(
		 * "delete from TraineeBean where traineeId=?",TraineeBean.class);
		 * query.setParameter(1, traineeId); query.executeUpdate();
		 */
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);
		if (bean != null) {
			entityManager.remove(bean);
		}
	}

	@Override
	public List<TraineeBean> viewAllTrainees() {

		TypedQuery<TraineeBean> query = entityManager.createQuery(
				"from TraineeBean", TraineeBean.class);
		return query.getResultList();

	}

	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);
		bean.setTraineeId(traineeId);
		bean.setTraineeName(traineeName);
		bean.setTraineeDomain(traineeDomain);
		bean.setTraineeLocation(traineeLocation);
		if (bean != null) {
			return entityManager.merge(bean);
		} else
			return null;
	}
	

}
