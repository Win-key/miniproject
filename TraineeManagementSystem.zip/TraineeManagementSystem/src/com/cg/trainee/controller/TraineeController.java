package com.cg.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	private ITraineeService service;

	public ITraineeService getService() {
		return service;
	}

	public void setService(ITraineeService service) {
		this.service = service;
	}

	/*
	 * @RequestMapping("/showHomePage") public ModelAndView showHomePage() {
	 * LoginBean login=new LoginBean(); ModelAndView mv=new
	 * ModelAndView("index"); mv.addObject("login", login); return mv; }
	 */

	@RequestMapping("/showHomePage")
	public ModelAndView show() {
		LoginBean login = new LoginBean();
		return new ModelAndView("index", "login", login);
	}

	@RequestMapping("/FirstPage")
	public ModelAndView FirstPage(@ModelAttribute("login") LoginBean login,
			BindingResult result) {
		ModelAndView mv = null;
		if (("Swathi").equals(login.getUsername())
				&& ("Shreehari").equals(login.getPassword())) {
			mv = new ModelAndView("firstPage", "login", login);
		} else {
			mv = new ModelAndView("loginError", "login", login);
		}
		return mv;
	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee() {
		TraineeBean trainee = new TraineeBean();
		return new ModelAndView("addTraineePage", "trainee", trainee);
	}

	@RequestMapping("/add")
	public ModelAndView add(
			@ModelAttribute("trainee") @Valid TraineeBean trainee,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			trainee = service.addTrainee(trainee);
			mv = new ModelAndView("addSuccess");
			/*
			 * mv.addObject("traineeId", trainee.getTraineeId());
			 * mv.addObject("traineeName", trainee.getTraineeName());
			 * mv.addObject("traineeDomain", trainee.getTraineeDomain());
			 * mv.addObject("traineeLocation", trainee.getTraineeLocation());
			 */

		} else {
			mv=new ModelAndView("addTraineePage", "trainee",trainee);
		}

		return mv;

	}

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee() {
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("deleteTraineePage");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");
		return mv;
	}

	@RequestMapping("/findById")
	public ModelAndView findById(
			@ModelAttribute("trainee") TraineeBean trainee, BindingResult result) {
		ModelAndView mv = new ModelAndView();

		TraineeBean trainee1 = new TraineeBean();
		trainee1 = service.findTrainee(trainee.getTraineeId());
		if (trainee1 != null) {
			mv.setViewName("deleteTraineePage");
			mv.addObject("trainee", trainee1);
		} else {
			mv.setViewName("findError");
			mv.addObject("trainee", trainee);
		}

		return mv;

	}

	/*
	 * @RequestMapping(value = "/delete", method = RequestMethod.POST) public
	 * ModelAndView delete(@RequestParam("traineeId") int traineeId) {
	 * 
	 * ModelAndView mv = new ModelAndView(); service.findTrainee(traineeId); if
	 * (traineeId != 0) { service.deleteTrainee(traineeId);
	 * mv.setViewName("delete"); }
	 * 
	 * return mv; }
	 */

	@RequestMapping("/delete")
	public ModelAndView delete(@ModelAttribute("trainee") TraineeBean trainee,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();

		TraineeBean trainee1 = new TraineeBean();
		if (trainee.getTraineeId() != 0) {
			service.deleteTrainee(trainee.getTraineeId());
			List<TraineeBean> list = service.viewAllTrainees();
			if (list.isEmpty()) {
				String msg = "There are no Donors";
				mv.setViewName("myError");
				mv.addObject("msg", msg);
			} 
			mv.setViewName("delete");
			mv.addObject("list", list);
		} else {
			mv.setViewName("deleteError");
			mv.addObject("trainee", trainee1);
		}
		return mv;
	}

	@RequestMapping("/retrieveAll")
	public ModelAndView retrieveAll() {
		ModelAndView mv = new ModelAndView();
		List<TraineeBean> list = service.viewAllTrainees();
		if (list.isEmpty()) {
			String msg = "There are no Donors";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllTraineesList");
			mv.addObject("list", list);
		}
		return mv;
	}

	@RequestMapping("/retrieveTrainee")
	public ModelAndView retrieveTrainee() {
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("retrieveTraineePage");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");
		return mv;
	}

	@RequestMapping("/findRetrieve")
	public ModelAndView findRetrive(
			@ModelAttribute("trainee") TraineeBean trainee, BindingResult result) {
		ModelAndView mv = new ModelAndView();

		TraineeBean trainee1 = new TraineeBean();
		trainee1 = service.findTrainee(trainee.getTraineeId());
		if (trainee1 != null) {
			mv.setViewName("retrieveTraineePage");
			mv.addObject("trainee", trainee1);
		} else {
			mv.setViewName("findError");
			mv.addObject("trainee", trainee);
		}

		return mv;
	}

	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee() {
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("modifyTraineePage");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");
		return mv;
	}

	@RequestMapping("/modifyById")
	public ModelAndView modifybyid(
			@ModelAttribute("trainee") TraineeBean trainee, BindingResult result) {
		ModelAndView mv = new ModelAndView();

		TraineeBean trainee1 = new TraineeBean();
		trainee1 = service.findTrainee(trainee.getTraineeId());
		if (trainee1 != null) {
			mv.setViewName("modifyTraineePage");
			mv.addObject("trainee", trainee1);
		} else {
			mv.setViewName("findError");
			mv.addObject("trainee", trainee);
		}

		return mv;
	}

	/*
	 * @RequestMapping(value = "/modify", method = RequestMethod.GET) public
	 * ModelAndView modify(@RequestParam("traineeId") int traineeId,
	 * 
	 * @RequestParam("traineeName") String traineeName,
	 * 
	 * @RequestParam("traineeDomain") String traineeDomain,
	 * 
	 * @RequestParam("traineeLocation") String traineeLocation) {
	 * 
	 * ModelAndView mv = new ModelAndView(); TraineeBean trainee = new
	 * TraineeBean(); TraineeBean trainee1 = service.modifyTrainee(traineeId,
	 * traineeName, traineeDomain, traineeLocation); if (trainee1 != null) {
	 * mv.setViewName("modify"); mv.addObject("trainee", trainee1); } return mv;
	 * 
	 * }
	 */

	@RequestMapping("/modify")
	public ModelAndView modify(@ModelAttribute("trainee") TraineeBean trainee,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();

		TraineeBean trainee1 = new TraineeBean();
		trainee1 = service.modifyTrainee(trainee.getTraineeId(),
				trainee.getTraineeName(), trainee.getTraineeDomain(),
				trainee.getTraineeLocation());
		if (trainee1 != null) {
			mv.setViewName("modify");
			mv.addObject("trainee", trainee1);
		} else {
			mv.setViewName("modifyError");
			mv.addObject("trainee", trainee1);
		}
		return mv;
	}

}
