package com.cg.ems.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9209244801807345131L;

	public EmployeeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
