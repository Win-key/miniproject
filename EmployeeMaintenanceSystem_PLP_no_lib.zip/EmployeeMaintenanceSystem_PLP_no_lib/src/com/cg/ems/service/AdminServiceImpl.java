package com.cg.ems.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.IAdminDao;
import com.cg.ems.entities.Employee;
import com.cg.ems.exception.EmployeeException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private IAdminDao dao;

	public IAdminDao getDao() {
		return dao;
	}

	public void setDao(IAdminDao dao) {
		this.dao = dao;
	}

	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		dao.addEmployee(employee);

	}

	@Override
	public Employee findEmployeeById(Employee employee)
			throws EmployeeException {
		
		return dao.findEmployeeById(employee);
	}

	@Override
	public Employee modifyEmployee(Employee employee) throws EmployeeException {
			return dao.modifyEmployee(employee);
	}

	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		
		return dao.viewAllEmployees();
	}

}
