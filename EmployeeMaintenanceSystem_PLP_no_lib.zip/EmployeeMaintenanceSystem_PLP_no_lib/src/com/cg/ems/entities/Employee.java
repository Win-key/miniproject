package com.cg.ems.entities;




import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="employee")
public class Employee {

	@Id
	@Column(name="emp_ID")
	@NotEmpty(message="Employee Id should not be empty")
	private String empID;
	
	@Column(name="emp_First_Name")
	@NotEmpty(message="Employee first name should not be empty")
	private String empFirstName;  
	
	@Column(name="emp_Last_Name")
	@NotEmpty(message="Employee last name should not be empty")
	private String empLastName;
	
	
	
//	private String empDateOfBirth;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@NotNull(message="Employee DOB should not be empty")
	@Column(name="emp_Date_of_Birth")
	private Date empDateOfBirth;
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="emp_Date_of_Joining")
	@NotNull(message="Employee DOJ should not be empty")
	private Date empDateOfJoining; 
	
	@Column(name="emp_Dept_ID")
	@Min(1)
	private int empDeptId;
	
	@Column(name="emp_Grade")
	@NotEmpty(message="Employee grade should not be empty")
	private String empGrade;
	
	@Column(name="emp_Designation")
	@NotEmpty(message="Employee destination should not be empty")
	private String empDesignation;
	
	@Column(name="emp_Basic")
	@Min(4)
	private double empBasic;
	
	@Column(name="emp_Gender")
	@NotEmpty(message="Employee gender should not be empty")
	private String empGender;
	
	@Column(name="emp_Marital_Status")
	@NotEmpty(message="Employee Marital Status should not be empty")
	private String empMaritalStatus; 
	
	@Column(name="emp_Home_Address")
	@NotEmpty(message="Employee Home Address should not be empty")
	private String empHomeAddress;
	
	@Column(name="emp_Contact_Num")
	@NotEmpty(message="Employee contact number should not be empty")
	private String empContactNum;
	
	@Column(name="mgr_Id")
	@NotEmpty(message="Employee manager id should not be empty")
	private String managerId;
	
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	
	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}
	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}
	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}
	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}
	public int getEmpDeptId() {
		return empDeptId;
	}
	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public double getEmpBasic() {
		return empBasic;
	}
	public void setEmpBasic(double empBasic) {
		this.empBasic = empBasic;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public String getEmpContactNum() {
		return empContactNum;
	}
	public void setEmpContactNum(String empContactNum) {
		this.empContactNum = empContactNum;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	
		
}
