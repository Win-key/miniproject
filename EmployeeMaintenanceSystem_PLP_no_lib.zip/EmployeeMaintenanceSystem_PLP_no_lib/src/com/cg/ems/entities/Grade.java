package com.cg.ems.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class Grade {

	@Id
	@NotEmpty(message="Employee grade should not be empty")
	private String employeeGrade;

	public String getEmployeeGrade() {
		return employeeGrade;
	}

	public void setEmployeeGrade(String employeeGrade) {
		this.employeeGrade = employeeGrade;
	}

	
	
	
}
