package com.cg.ems.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="user_master")
public class User {
	
	@Id
	@Column(name="username")
	@NotEmpty(message="User name cannot be empty")
	@Pattern(regexp="^[a-zA-Z]+$")
	private String userName;
	
	@Column(name="password")
	@NotEmpty(message="Password cannot be empty")
	@Pattern(regexp="^[a-zA-Z0-9]+$")
	private String password;
	
	@Column(name="userId")
	private String userId;
	
	@Column(name="userType")
	private String userType;
	
	public User(){
		
	}

	
	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}

	
	
}
