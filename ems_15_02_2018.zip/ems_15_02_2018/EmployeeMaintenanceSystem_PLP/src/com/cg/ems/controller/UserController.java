package com.cg.ems.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IUserService;

@Controller
public class UserController {

	@Autowired
	private IUserService service;

	public IUserService getService() {
		return service;
	}

	public void setService(IUserService service) {
		this.service = service;
	}

	@RequestMapping("/showHomeScreen")
	public String showHomeScreen() {
		return "homeScreen";
	}

	@RequestMapping("/loginScreen")
	public ModelAndView loginScreen(@ModelAttribute("user")@Valid User user,
			BindingResult result) {
		ModelAndView mv = new ModelAndView("loginScreen", "user", user);
		return mv;

	}

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute("user")@Valid User user,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if(!result.hasErrors()){
		
		try {

			String userName = user.getUserName();
			String userPassword = user.getPassword();
			
			String userType = service.getRole(userName,userPassword);
			if (userType != null) {
				if (userType.equals("admin")) {
					mv.setViewName("adminScreen");
				} else if(userType.equals("employee")) {
					mv.setViewName("employeeScreen");
				}

			}
		} catch (EmployeeException e) {
			mv.setViewName("errorScreen");
		}
		}
		else
		{
			mv.setViewName("errorScreen");
		}
		return mv;
	}

}
