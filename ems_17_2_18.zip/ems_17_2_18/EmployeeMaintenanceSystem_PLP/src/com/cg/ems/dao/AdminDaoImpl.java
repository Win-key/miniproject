package com.cg.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ems.entities.Employee;
import com.cg.ems.exception.EmployeeException;

@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao{

	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		
		entityManager.persist(employee);
		
	}

	@Override
	public Employee findEmployeeById(Employee employee)
			throws EmployeeException {
		Employee emp=entityManager.find(Employee.class, employee.getEmpID());
		return emp;
	}

	@Override
	public Employee modifyEmployee(Employee employee) throws EmployeeException {
		System.out.println(employee.getEmpID());
		Employee emp=entityManager.find(Employee.class, employee.getEmpID());
		
		emp.setEmpID(employee.getEmpID());
	System.out.println(emp.getEmpID());
		emp.setEmpFirstName(employee.getEmpFirstName());
		emp.setEmpLastName(employee.getEmpLastName());
		emp.setEmpDateOfBirth(employee.getEmpDateOfBirth());
		emp.setEmpDateOfJoining(employee.getEmpDateOfJoining());
		emp.setEmpDeptId(employee.getEmpDeptId());
		emp.setEmpGrade(employee.getEmpGrade());
		emp.setEmpDesignation(employee.getEmpDesignation());
		emp.setEmpBasic(employee.getEmpBasic());
		emp.setEmpGender(employee.getEmpGender());
		emp.setEmpMaritalStatus(employee.getEmpMaritalStatus());
		emp.setEmpHomeAddress(employee.getEmpHomeAddress());
		emp.setEmpContactNum(employee.getEmpContactNum());
		emp.setManagerId(employee.getManagerId());
		
		if(emp!=null){
		return entityManager.merge(emp);
		}
		else
			return null;
	}

	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		TypedQuery< Employee> query=entityManager.createQuery("from Employee",Employee.class);
		return query.getResultList();
	}

	



}
