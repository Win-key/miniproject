package com.cg.ems.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.IUserDao;
import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserDao dao;

	public IUserDao getDao() {
		return dao;
	}

	public void setDao(IUserDao dao) {
		this.dao = dao;
	}

	@Override
	public String getRole(String username, String password)
			throws EmployeeException {
		String userType = null;
		
		User user = dao.getUserByName(username);
		
		if (user == null) {
			throw new EmployeeException("Please enter valid user name!!!!");
		} else if (!password.equals(user.getPassword())) {
			throw new EmployeeException("Please enter the correct password!!");
		} else {
			userType = user.getUserType();
		}
		return userType;
	}
}
