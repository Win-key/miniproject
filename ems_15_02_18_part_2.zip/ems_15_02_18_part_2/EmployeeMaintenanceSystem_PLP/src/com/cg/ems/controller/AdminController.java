package com.cg.ems.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.Employee;

@Controller
@RequestMapping(value="*.adm")
public class AdminController {
	
	@RequestMapping(value="/addEmployeeForm")
	public ModelAndView addEmployeeForm() {
		Employee employee = new Employee();
		return new ModelAndView("addEmployee", "employee", employee);
	}
	
	@RequestMapping(value="/addEmployee")
	public ModelAndView addEmployee(@ModelAttribute("employee") Employee employee) {
		
		System.out.println(employee.getEmpDateOfBirth().toString());
		
		return null;
		
	}
	
	
}
