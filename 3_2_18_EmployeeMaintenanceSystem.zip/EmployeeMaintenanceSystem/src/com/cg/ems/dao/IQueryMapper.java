package com.cg.ems.dao;

public interface IQueryMapper {
	
	public static final String SELECT_USER_BYNAME = "SELECT username,password,userid,usertype FROM user_master WHERE username=?";
	public static final String ADD_EMPLOYEE_QUERY="INSERT INTO employee"
			+ "(Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic, Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id)"
			+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATE_EMPLOYEE_QUERY="UPDATE employee SET Emp_First_Name=?,Emp_Last_Name=?,Emp_Date_of_Birth=?,Emp_Date_of_Joining=?,Emp_Dept_ID=?,Emp_Grade=?,Emp_Designation=?,Emp_Basic=?, Emp_Gender=?,Emp_Marital_Status=?,Emp_Home_Address=?,Emp_Contact_Num=?,Mgr_Id=? WHERE Emp_ID=?";
	public static final String VIEW_ALL_EMPLOYEES="SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee";		
}
