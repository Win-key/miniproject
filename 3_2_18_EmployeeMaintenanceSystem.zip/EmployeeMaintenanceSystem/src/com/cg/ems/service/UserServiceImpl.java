package com.cg.ems.service;

import com.cg.ems.bean.User;
import com.cg.ems.dao.IUserDao;
import com.cg.ems.dao.UserDaoImpl;
import com.cg.ems.exception.EmployeeException;

public class UserServiceImpl implements IUserService {

	IUserDao dao = new UserDaoImpl();
	
	@Override
	public String getRole(String username, String password)
			throws EmployeeException {
		
		String userType = null;
		User user = dao.getUserByName(username);
		if(user.getUserName()==null){
			throw new EmployeeException("No such user name");
		}else if (!password.equals(user.getPassword())) {
			throw new EmployeeException("Password is not matched");
		}else{
			userType = user.getUserType();
		}
		return userType;
	}

	
	
}
