package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.IAdminDao;
import com.cg.ems.exception.EmployeeException;

public class AdminServiceImpl implements IAdminService{
	
	IAdminDao dao= new AdminDaoImpl();
	
	@Override
	public int AddEmployee(Employee employee) throws EmployeeException {
		
		return dao.AddEmployee(employee);
	}

	@Override
	public int modifyEmployee(Employee employee) throws EmployeeException {
		
		return dao.modifyEmployee(employee);
	}

	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		
		return dao.viewAllEmployees();
	}


	
		
}
