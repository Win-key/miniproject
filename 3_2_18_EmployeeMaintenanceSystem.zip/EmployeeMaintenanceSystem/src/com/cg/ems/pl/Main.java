
package com.cg.ems.pl;

import java.util.Scanner;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IUserService;
import com.cg.ems.service.UserServiceImpl;

public class Main {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		IUserService service = new UserServiceImpl();
		
		while (true) {
			System.out.println("1.Login :: 2.Quit");
			int key = input.nextInt();input.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter the username");
				String username = input.nextLine();
				System.out.println("Enter the password");
				String password = input.nextLine();
				
				try {
					String userType = service.getRole(username, password);
					if(userType.equalsIgnoreCase("admin")){
						
						System.out.println("Hi admin");
						AdminConsole admin = new AdminConsole(username);
						admin.start();
					}else{
						System.out.println("Hi Employee");
					}
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				
				System.out.println("Bye");
				input.close();
				System.exit(1);
				break;
				
			default:
				System.out.println("NO such options");
				break;
			}
		}
		
	}
	
}
