package com.cg.ems.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ems.exception.EmployeeException;

public class DBConnection {

	public static Connection getConnection() throws EmployeeException {
		

		Connection con = null;
		
		try {
			Properties prop = new Properties();
			FileReader fr = new FileReader("resources/jdbc.properties");
			prop.load(fr);
			
			//String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String pass = prop.getProperty("pass");

			//Class.forName(driver); no need for adding driver if it is in the ClassPath
			//(feature of jdbc 4.0)
			
			System.out.println("Driver loaded successfully");
			
			con = DriverManager.getConnection(url,user,pass);
		} catch (FileNotFoundException e) {
			throw new EmployeeException("JDBC Properties File not found " + e.getMessage());
		} catch (IOException e) {
			throw new EmployeeException("Unable to read the file");
		} catch (SQLException e) {
			throw new EmployeeException("sql exception " + e.getMessage());
		}
		
		
		
		return con;
		
	}
	
}
