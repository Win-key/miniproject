package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.LeaveBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {

	Connection con = null;

	@Override
	public Employee searchById(String id) throws EmployeeException {
		Employee employee = null;

		con = DBConnection.getConnection();
		try {
			employee = new Employee();
			PreparedStatement pstmt = con
					.prepareStatement(IQueryMapper.SEARCH_BY_ID);
			pstmt.setString(1, id);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));
			}
		} catch (SQLException e) {
			throw new EmployeeException("SQL exception " + e.getMessage());
		}

		return employee;
	}

	@Override
	public List<Employee> searchByFN(String fName) throws EmployeeException {
		List<Employee> list = new ArrayList<Employee>();
		con = DBConnection.getConnection();
		String query = IQueryMapper.SEARCH_BY_FN;
		Employee employee = new Employee();

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, fName);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("No employees found in the database");
		}

		return list;
	}

	@Override
	public List<Employee> searchByLN(String lName) throws EmployeeException {
		List<Employee> list = new ArrayList<Employee>();
		con = DBConnection.getConnection();
		String query = IQueryMapper.SEARCH_BY_LN;
		Employee employee = new Employee();

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, lName);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("No employees found in the database");
		}

		return list;
	}

	@Override
	public List<Employee> searchByDepId(int dept) throws EmployeeException {
		List<Employee> list = new ArrayList<Employee>();
		con = DBConnection.getConnection();
		String query = IQueryMapper.SEARCH_BY_DEPT;
		Employee employee = new Employee();

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, dept);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("No employees found in the database");
		}

		return list;
	}

	@Override
	public List<Employee> searchByGrade(String grade) throws EmployeeException {
		List<Employee> list = new ArrayList<Employee>();
		con = DBConnection.getConnection();
		String query = IQueryMapper.SEARCH_BY_GRADE;
		Employee employee = new Employee();

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, grade);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("No employees found in the database");
		}

		return list;

	}

	@Override
	public List<Employee> searchByMarital(String marital)
			throws EmployeeException {
		List<Employee> list = new ArrayList<Employee>();
		con = DBConnection.getConnection();
		String query = IQueryMapper.SEARCH_BY_MARITAL;
		Employee employee = new Employee();

		try {
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, marital);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate(
						"Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate(
						"Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result
						.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EmployeeException("No employees found in the database");
		}

		return list;

	}

	@Override
	public int applyLeave(LeaveBean leave) throws EmployeeException {
		int count = 0;
		con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(IQueryMapper.EMP_LEAVE_DETAILS);
			pstmt.setString(1, leave.getEmp_id());
			ResultSet rst = null; 
			rst = pstmt.executeQuery();
			
			if(!rst.next()){
				pstmt = con.prepareStatement(IQueryMapper.APPLY_LEAVE);
				pstmt.setString(1, leave.getEmp_id());
				pstmt.setInt(2, 12);
				pstmt.setInt(3, leave.getNoofdays_applied());
				
				Date utilDF =leave.getDate_from();			
				java.sql.Date sqlDF = new java.sql.Date(utilDF.getTime());
				pstmt.setDate(4, sqlDF);
				
				Date utilDT =leave.getDate_to();
				java.sql.Date sqlDT = new java.sql.Date(utilDT.getTime());
				pstmt.setDate(5, sqlDT);
				
				count = pstmt.executeUpdate();
				
			}else{
				System.out.println("Having records");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}

}
