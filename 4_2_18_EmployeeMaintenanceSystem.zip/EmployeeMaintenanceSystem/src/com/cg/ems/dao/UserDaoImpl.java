package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ems.bean.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class UserDaoImpl implements IUserDao{

	@Override
	public User getUserByName(String name) throws EmployeeException {
		User user = null;
		Connection con = null;
		
		try {
			con = DBConnection.getConnection();
			user = new User();
			PreparedStatement pstmt = con.prepareStatement(IQueryMapper.SELECT_USER_BYNAME);
			pstmt.setString(1, name);
			System.out.println(name);
			ResultSet rst = pstmt.executeQuery();
						
			if (rst.next()) {
				
				user.setUserName(rst.getString("username"));
				user.setPassword(rst.getString("password"));
				user.setUserId(rst.getString("userid"));
				user.setUserType(rst.getString("usertype"));
			}
		} catch (SQLException e) {
			
			throw new EmployeeException("Unable to fetch data " + e.getMessage());
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new EmployeeException("Unable to close the connection " + e.getMessage());
				
			}
		}
		
		return user;
	}

	
	
	
}
