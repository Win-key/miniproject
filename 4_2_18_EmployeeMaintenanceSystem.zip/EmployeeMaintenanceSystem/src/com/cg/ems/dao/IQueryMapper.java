package com.cg.ems.dao;

public interface IQueryMapper {
	
	public static final String SELECT_USER_BYNAME = "SELECT username,password,userid,usertype FROM user_master WHERE username=?";
	public static final String ADD_EMPLOYEE_QUERY="INSERT INTO employee"
			+ "(Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic, Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id)"
			+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATE_EMPLOYEE_QUERY="UPDATE employee SET Emp_First_Name=?,Emp_Last_Name=?,Emp_Date_of_Birth=?,Emp_Date_of_Joining=?,Emp_Dept_ID=?,Emp_Grade=?,Emp_Designation=?,Emp_Basic=?, Emp_Gender=?,Emp_Marital_Status=?,Emp_Home_Address=?,Emp_Contact_Num=?,Mgr_Id=? WHERE Emp_ID=?";
	public static final String VIEW_ALL_EMPLOYEES="SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee";
	
	
	public static final String SEARCH_BY_ID = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_ID=?";
	public static final String SEARCH_BY_FN = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_First_Name=?";
	public static final String SEARCH_BY_LN = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_Last_Name=?";
	public static final String SEARCH_BY_DEPT = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_Dept_ID=?";
	public static final String SEARCH_BY_MARITAL = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_Marital_Status=?";
	public static final String SEARCH_BY_GRADE = "SELECT Emp_ID,Emp_First_Name,Emp_Last_Name ,Emp_Date_of_Birth,Emp_Date_of_Joining,Emp_Dept_ID,Emp_Grade,Emp_Designation,Emp_Basic,Emp_Gender,Emp_Marital_Status,Emp_Home_Address,Emp_Contact_Num,Mgr_Id FROM employee WHERE Emp_Grade=?";
	
	public static final String EMP_LEAVE_DETAILS = "SELECT Leave_Id,Emp_id,leave_balance,noofdays_applied,date_from,date_to,status FROM leave_history WHERE Emp_id = ?";
	public static final String APPLY_LEAVE = "INSERT INTO leave_history VALUES(leave_seq.NEXTVAL, ?, ?, ?, ?, ?, 'applied')";
	
	
}
