package com.cg.ems.pl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.LeaveBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class EmployeeConsole {

	IEmployeeService service = new EmployeeServiceImpl();
	private String userName;
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
	Date date;
	
	public EmployeeConsole(String userName) {
		this.userName = userName;
	}
	
	public void start() {
		System.out.println("Welcome " + userName);
		Scanner scanner=new Scanner(System.in);
		
		while (true) {
			System.out.println("1.Search by id \n 2.Search by First name \n 3.Search by Last Name\n 4."
					+ "Search by department \n5.Search by Grade \n6.Search by marital status\n"
					+ "7.Apply Leave \n 8.Exit");
			int key = scanner.nextInt();scanner.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter the id to search");
				try {
					Employee emp = service.searchById(scanner.nextLine());
					System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + emp.getEmpDateOfBirth() + " " +emp.getEmpDateOfJoining());
				} catch (EmployeeException e) {
					System.out.println("Exception " + e.getMessage());
					
				}
				break;
			case 2:
				System.out.println("Enter first name to search");
				try {
					List<Employee> list = service.searchByFN(scanner.nextLine());
					for (Employee emp : list) {
						String d1=dateFormat.format(emp.getEmpDateOfBirth());
						String d2 = dateFormat.format(emp.getEmpDateOfJoining());
						System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + d1 + " " + d2);
					}
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					System.out.println("Exception " +e.getMessage());
				}
				
				break;
			case 3:
				System.out.println("Enter last name to search");
				try {
					List<Employee> list = service.searchByLN(scanner.nextLine());
					for (Employee emp : list) {
						String d1=dateFormat.format(emp.getEmpDateOfBirth());
						String d2 = dateFormat.format(emp.getEmpDateOfJoining());
						System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + d1 + " " + d2);
					}
				} catch (EmployeeException e) {
					System.out.println("Exception " +e.getMessage());
				}
				break;
				
			case 4:
				System.out.println("Enter Department id to search");
				try {
					List<Employee> list = service.searchByDepId(scanner.nextInt());scanner.nextLine();
					for (Employee emp : list) {
						String d1=dateFormat.format(emp.getEmpDateOfBirth());
						String d2 = dateFormat.format(emp.getEmpDateOfJoining());
						System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + d1 + " " + d2);
					}
				} catch (EmployeeException e) {
					System.out.println("Exception " +e.getMessage());
				}
				break;
				
			case 5:
				System.out.println("Enter Grade to search");
				try {
					List<Employee> list = service.searchByGrade(scanner.nextLine());
					for (Employee emp : list) {
						String d1=dateFormat.format(emp.getEmpDateOfBirth());
						String d2 = dateFormat.format(emp.getEmpDateOfJoining());
						System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + d1 + " " + d2);
					}
				} catch (EmployeeException e) {
					System.out.println("Exception " +e.getMessage());
				}
				break;
			case 6:
				System.out.println("Enter marital to search");
				try {
					List<Employee> list = service.searchByMarital(scanner.nextLine());
					for (Employee emp : list) {
						String d1=dateFormat.format(emp.getEmpDateOfBirth());
						String d2 = dateFormat.format(emp.getEmpDateOfJoining());
						System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" " + d1 + " " + d2);
					}
				} catch (EmployeeException e) {
					System.out.println("Exception " +e.getMessage());
				}
				break;
				
			case 7:
				try {
					LeaveBean leave = new LeaveBean();
					System.out.println("Enter employee ID");
					leave.setEmp_id(scanner.nextLine());
					System.out.println("Enter No of leave you are going to apply");
					leave.setNoofdays_applied(scanner.nextInt());scanner.nextLine();
					System.out.println("From Date");
					String Df = scanner.nextLine();
					Date dateFrom = dateFormat.parse(Df);
					leave.setDate_from(dateFrom);
					System.out.println("To Date");
					String Dt = scanner.nextLine();
					Date dateTo = dateFormat.parse(Dt);
					leave.setDate_to(dateTo);
					int count = service.applyLeave(leave);
					if (count>0) {
						System.out.println("Leave applied successfully");
					}
				} catch (ParseException e) {
					System.out.println("Date entered in wrong formate");
				} catch (EmployeeException e) {
					System.out.println("Exception :: " + e.getMessage());
				}
				break;
			case 8: 
				scanner.close();
				System.exit(1);
				break;

			}
		}
	}
	
}
