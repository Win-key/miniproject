package com.cg.ems.bean;

import java.util.Date;

public class LeaveBean {

	private int Leave_Id;
	private String Emp_id;
	private int leave_balance;
	private int noofdays_applied;
	private Date date_from; 
	private Date date_to;
	private String status ;
	
	
	public LeaveBean() {
		
	}
	
	public int getLeave_Id() {
		return Leave_Id;
	}
	public void setLeave_Id(int leave_Id) {
		Leave_Id = leave_Id;
	}
	public String getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(String emp_id) {
		Emp_id = emp_id;
	}
	public int getLeave_balance() {
		return leave_balance;
	}
	public void setLeave_balance(int leave_balance) {
		this.leave_balance = leave_balance;
	}
	public int getNoofdays_applied() {
		return noofdays_applied;
	}
	public void setNoofdays_applied(int noofdays_applied) {
		this.noofdays_applied = noofdays_applied;
	}
	public Date getDate_from() {
		return date_from;
	}
	public void setDate_from(Date date_from) {
		this.date_from = date_from;
	}
	public Date getDate_to() {
		return date_to;
	}
	public void setDate_to(Date date_to) {
		this.date_to = date_to;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
