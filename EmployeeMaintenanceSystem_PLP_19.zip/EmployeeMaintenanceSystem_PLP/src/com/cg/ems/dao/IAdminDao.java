package com.cg.ems.dao;


import java.util.List;

import com.cg.ems.entities.Employee;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.exception.EmployeeException;

public interface IAdminDao {

	public void addEmployee(Employee employee)throws EmployeeException;
	public Employee findEmployeeById(Employee employee)throws EmployeeException;
	public Employee modifyEmployee(Employee employee)throws EmployeeException;
	public List<Employee> viewAllEmployees()throws EmployeeException;
	
}
