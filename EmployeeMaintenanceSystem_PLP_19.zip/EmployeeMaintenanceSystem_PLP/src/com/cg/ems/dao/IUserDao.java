package com.cg.ems.dao;


import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

public interface IUserDao {
	
	public User getUserByName(String name) throws EmployeeException;
	
}
