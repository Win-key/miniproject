package com.cg.ems.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class ActionBean {

	@Id
	@NotEmpty(message="Employee id should not be empty")
	private String empId;
	
	@NotEmpty(message="Action should be selected")
	private String action;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	
}
