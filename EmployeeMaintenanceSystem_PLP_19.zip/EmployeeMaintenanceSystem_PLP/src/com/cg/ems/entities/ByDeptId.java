package com.cg.ems.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class ByDeptId {

	@Id
	@NotEmpty(message="Employee first name should not be empty")
	@Min(1)
	@Max(1)
	@Pattern(regexp="^[0-9]$",message="Department id must contain only numbers")
	private int empDeptId;

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}
	
	
	
}
