package com.cg.ems.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="leave_history")
public class LeaveBean {

	@Id
	@Column(name="leave_Id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int leaveId;
	
	@Column(name="Emp_id")
	@NotEmpty(message="Employee Id should not be empty")
	private String empId;
	
	@Column(name="leave_balance")
	private int leaveBalance;
	
	@Column(name="noofdays_applied")
	private int noofdaysApplied;
	
	@Column(name="date_from")
	@NotNull(message="From date should not be null")
	private Date dateFrom;
	
	@Column(name="date_to")
	@NotNull(message="To date should not be null")
	private Date dateTo;
	
	@Column(name="status")
	private String approvalStatus ;
	
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public int getLeaveBalance() {
		return leaveBalance;
	}
	public void setLeaveBalance(int leaveBalance) {
		this.leaveBalance = leaveBalance;
	}
	public int getNoofdaysApplied() {
		return noofdaysApplied;
	}
	public void setNoofdaysApplied(int noofdaysApplied) {
		this.noofdaysApplied = noofdaysApplied;
	}
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	
	
	
}
