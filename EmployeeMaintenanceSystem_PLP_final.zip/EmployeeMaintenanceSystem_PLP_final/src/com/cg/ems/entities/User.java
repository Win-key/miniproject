package com.cg.ems.entities;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="user_master")
public class User {
	
	@Id
	@NotEmpty(message="Name should not be empty")
	@Pattern(regexp="^[a-zA-Z0-9]+$",message="Username should contain only alphabets and numbers")
	private String userName;
	
	@NotEmpty(message="Password should not be empty")
	@Pattern(regexp="^[a-zA-Z0-9\\@]+$",message="Password can contain only number,@ or alplabets")
	private String password;
	
	private String userId;
	
	private String userType;
	
	public User(){
		
	}

	
	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}

	
	
}
