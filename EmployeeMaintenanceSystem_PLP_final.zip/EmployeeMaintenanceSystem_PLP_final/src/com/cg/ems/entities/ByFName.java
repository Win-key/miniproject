package com.cg.ems.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class ByFName {
	
	@Id
	@NotEmpty(message="Employee first name should not be empty")
	@Pattern(regexp = "^[a-zA-z]+$", message = "The First name of the employee should contain only alphabets")
	private String empFirstName;

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	
	
	
}
