package com.cg.ems.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import javax.validation.constraints.Pattern;

@Entity
public class Lname {

	@Id
	@Pattern(regexp = "^[a-zA-z]+$", message = "The last name of the employee should contain only alphabets")
	private String lastName;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
