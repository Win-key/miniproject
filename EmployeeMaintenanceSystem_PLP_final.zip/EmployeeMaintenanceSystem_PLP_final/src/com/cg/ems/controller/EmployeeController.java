package com.cg.ems.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.ActionBean;
import com.cg.ems.entities.ByFName;
import com.cg.ems.entities.ByIdBean;
import com.cg.ems.entities.Employee;
import com.cg.ems.entities.Grade;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.entities.Lname;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IEmployeeService;

@Controller
@RequestMapping(value = "*.emp")
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping(value = "/applyLeaveForm")
	public ModelAndView applyLeaveForm(HttpServletRequest request) {
		
		LeaveBean leave = new LeaveBean();
		leave.setEmpId((String)request.getSession().getAttribute("id"));
		return new ModelAndView("applyLeave", "leave", leave);
	}

	@RequestMapping(value = "/applyLeave")
	public ModelAndView applyLeave(
			@ModelAttribute("leave") @Valid LeaveBean leave,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			try {
				
				long diff = leave.getDateTo().getTime() - leave.getDateFrom().getTime();
				int noofdaysApplied = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				if (noofdaysApplied<0) {
					throw new EmployeeException("Date from which you are applying leave cannot be lesser than the date until when you are applying");
				}
				Employee bean = service.findEmployeeById(leave.getEmpId());
				if (bean != null) {

					LeaveBean leaveBean = service.findLeaveById(leave
							.getEmpId());
					if (leaveBean == null) {
						service.addLeave(leave);
						mv = new ModelAndView("success", "message",
								"Leave applied successfully!");
					} else {
						if (leaveBean.getApprovalStatus().equals("applied")) {
							mv = new ModelAndView("success", "message",
									"Your previous leave application is still in process!");
						} else {
							leaveBean.setDateFrom(leave.getDateFrom());
							leaveBean.setDateTo(leave.getDateTo());
							service.updateLeave(leaveBean);
							mv = new ModelAndView("success", "message",
									"Leave applied successfully!");
						}

					}

				} else {
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!!Employee with the given id doesn't exist");
				}
			} catch (EmployeeException e) {
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!! " + e.getMessage());
				e.printStackTrace();
			}
		} else {
			mv = new ModelAndView("applyLeave", "leave", leave);
		}

		return mv;
	}

	@RequestMapping(value = "/approveLeaveForm")
	public ModelAndView approveLeaveForm() {
		ActionBean actionBean = new ActionBean();
		return new ModelAndView("approveLeave", "actionBean", actionBean);
	}

	@RequestMapping(value = "/approveLeave")
	public ModelAndView approveLeave(
			@ModelAttribute("actionBean") @Valid ActionBean actionBean,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			try {
				Employee bean = service.findEmployeeById(actionBean.getEmpId());
				if (bean != null) {
					LeaveBean leaveBean = service.findLeaveById(actionBean
							.getEmpId());
					if (leaveBean == null) {
						mv = new ModelAndView("success", "message",
								"The employee hasn't applied for leave");
					} else {
						if (leaveBean.getApprovalStatus().equals("applied")) {
							leaveBean.setApprovalStatus(actionBean.getAction());
							int count = service.approveLeave(leaveBean);
							if (count == 0) {
								mv = new ModelAndView("success", "message",
										"Leave approved successfully");
							} else if(count == 1) {
								mv = new ModelAndView("success", "message",
										"Leave has been rejected");
							}else{
								mv = new ModelAndView("success", "message",
										"Insufficient leave");
							}

						} else {
							mv = new ModelAndView("success", "message",
									"Action on this leave is already taken");
						}
					}
				} else {
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!! Employee with given id doesn't exist");
				}
			} catch (EmployeeException e) {
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!!Employee leave could not be approved! "
								+ e.getMessage());

			}
		} else {
			mv = new ModelAndView("approveLeave", "actionBean", actionBean);
		}

		return mv;
	}

	@RequestMapping(value = "/viewbyidForm")
	public ModelAndView viewByIdForm() {
		ByIdBean byId = new ByIdBean();
		ModelAndView mv = new ModelAndView("viewByForm", "byId", byId);
		mv.addObject("isId", true);
		return mv;
	}

	@RequestMapping(value = "/viewbyid")
	public ModelAndView viewbyid(@ModelAttribute("byId") @Valid ByIdBean byId,
			BindingResult result) {

		ModelAndView mv = null;
		try {
			if (!result.hasErrors()) {
				Employee employee = service.findEmployeeById(byId.getEmpId());
				List<Employee> list = new ArrayList<Employee>();
				list.add(employee);
				if (employee == null) {
					mv = new ModelAndView("searchDisplay", "isThere", false);
					mv.addObject("message","No employee found with the given id!");
				} else {
					mv = new ModelAndView("searchDisplay", "list", list);
					mv.addObject("isThere", true);
				}
			}

			else {
				mv = new ModelAndView("viewByForm", "byId", byId);
				mv.addObject("isId", true);
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

	@RequestMapping(value = "/viewbyfnameForm")
	public ModelAndView viewbyfnameForm() {
		ByFName byFName = new ByFName();
		ModelAndView mv = new ModelAndView("viewByForm", "byFName", byFName);
		mv.addObject("isFname", true);
		return mv;
	}

	@RequestMapping(value = "/viewbyfname")
	public ModelAndView viewbyfname(
			@ModelAttribute("byFName") @Valid ByFName byFName,
			BindingResult result) {

		ModelAndView mv = null;

		try {
			if (!result.hasErrors()) {
				List<Employee> list = service.findEmployeeByFName(byFName
						.getEmpFirstName());
				if (list.isEmpty()) {
					mv = new ModelAndView("searchDisplay", "isThere", false);
					mv.addObject("message","No employees found with the given first name!");
				} else {
					mv = new ModelAndView("searchDisplay", "list", list);
					mv.addObject("isThere", true);
				}
			} else {
				mv = new ModelAndView("viewByForm", "byFName", byFName);
				mv.addObject("isFname", true);
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

	@RequestMapping(value = "/viewbygradeForm")
	public ModelAndView viewbygradeForm() {
		Grade grade = new Grade();
		ModelAndView mv = new ModelAndView("viewByForm", "grade", grade);
		mv.addObject("isGrade", true);
		return mv;
	}

	@RequestMapping(value = "/viewbygrade")
	public ModelAndView viewbygrade(
			@ModelAttribute("grade") @Valid Grade grade, BindingResult result) {

		ModelAndView mv = null;

		try {
			if (!result.hasErrors()) {
				List<Employee> list = service.findEmployeeByGrade(grade
						.getEmployeeGrade());
				if (list.isEmpty()) {
					mv = new ModelAndView("searchDisplay", "isThere", false);
					mv.addObject("message","No employees found with the given grade!");
				} else {
					mv = new ModelAndView("searchDisplay", "list", list);
					mv.addObject("isThere", true);
				}
			} else {
				mv = new ModelAndView("viewByForm", "grade", grade);
				mv.addObject("isGrade", true);
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}
	
	@RequestMapping(value = "/viewbylnameForm")
	public ModelAndView viewbylnameForm() {
		Lname lName=new Lname();
		ModelAndView mv = new ModelAndView("viewByForm", "lName", lName);
		mv.addObject("isLname", true);
		return mv;
	}

	@RequestMapping(value = "/viewbylname")
	public ModelAndView viewbylname(
			@ModelAttribute("lName") @Valid Lname lName,
			BindingResult result) {

		ModelAndView mv = null;

		try {
			if (!result.hasErrors()) {
				List<Employee> list = service.findEmployeeByLname(lName.getLastName());
				if (list.isEmpty()) {
					mv = new ModelAndView("searchDisplay", "isThere", false);
					mv.addObject("message","No employees found with the given last name!");
				} else {
					mv = new ModelAndView("searchDisplay", "list", list);
					mv.addObject("isThere", true);
				}
			} else {
				mv = new ModelAndView("viewByForm","lName", lName);
				mv.addObject("isLname", true);
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

}
