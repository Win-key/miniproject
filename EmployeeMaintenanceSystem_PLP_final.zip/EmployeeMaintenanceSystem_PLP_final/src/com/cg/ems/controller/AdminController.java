package com.cg.ems.controller;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.Employee;
import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IAdminService;

@Controller
@RequestMapping(value = "*.adm")
public class AdminController {

	@Autowired
	private IAdminService service;

	public IAdminService getService() {
		return service;
	}

	public void setService(IAdminService service) {
		this.service = service;
	}

	@RequestMapping(value = "/addEmployeeForm")
	public ModelAndView addEmployeeForm() {
		Employee employee = new Employee();
		return new ModelAndView("addEmployee", "employee", employee);
	}

	@RequestMapping(value = "/addEmployee")
	public ModelAndView addEmployee(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try {
				
				long diff = employee.getEmpDateOfJoining().getTime() - employee.getEmpDateOfBirth().getTime();
				int daysDiff = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				int yearDif = daysDiff/365;
				if (yearDif<18 || yearDif>60) {
					throw new EmployeeException("Employee age should be greater than 18 and less than 60");
				}
				
				Employee bean  = service.findEmployeeById(employee);

				if (bean == null) {
					Employee employee1=service.findManagerById(employee.getManagerId());
					if(employee1!=null){
					service.addEmployee(employee);
					mv = new ModelAndView();
					mv.setViewName("success");
					mv.addObject("message", "Added successfully");
					mv.addObject("employee", employee);

				}
				else
					{

					mv = new ModelAndView("errorScreen", "message",
							"Sorry!Manager with the given Id does not exist!");
					}
				}
					else {
					
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!An employee with the same Id already exist!");
				}
			} catch (EmployeeException e) {
				mv = new ModelAndView("errorScreen", "message", "Could not add the employee details!!"+e.getMessage());
			}
		} else {
			mv = new ModelAndView("addEmployee", "employee", employee);
		}

		return mv;

	}

	@RequestMapping(value = "/modifyEmployee")
	public ModelAndView modifyEmployee() {
		Employee employee = new Employee();
		return new ModelAndView("modifyScreen", "employee", employee);
	}
	
	@RequestMapping(value = "/modifyEmployeeId")
	public ModelAndView modifyEmployeeId(
			@ModelAttribute("employee")  Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			Employee employee1 = service.findEmployeeById(employee);
			if (employee1!=null) {
				mv.setViewName("modifyById");
				mv.addObject("employee",employee1);
			}
 else {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be modified!");
}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be modified!");
		}
		return mv;
		
	}
	

	@RequestMapping(value="/modify")
	public ModelAndView modify(
			@ModelAttribute("employee")@Valid Employee employee,BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if(!result.hasErrors()){
		try {
			
			long diff = employee.getEmpDateOfJoining().getTime() - employee.getEmpDateOfBirth().getTime();
			int daysDiff = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			int yearDif = daysDiff/365;
			if (yearDif<18 || yearDif>60) {
				throw new EmployeeException("Employee age should be greater than 18 and less than 60");
			}
			
			Employee employeeObj=service.modifyEmployee(employee);
			if(employeeObj!=null){
				
			mv.setViewName("success");
			mv.addObject("employee",employeeObj);
			mv.addObject("message", "Employee details modifie");
			}
			else
			{
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details could not be modified!");
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be modified!"+e.getMessage());
		}
		}
		else
		{
			mv.setViewName("modifyById");
			mv.addObject("employee",employee);
		}
		return mv;
	
	}
	
	@RequestMapping(value="/displayAllEmployees")
	public ModelAndView displayAllEmployees(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			List<Employee> list=service.viewAllEmployees();
			if(!list.isEmpty()){
			mv.setViewName("displayScreen");
			mv.addObject("list", list);
			}
			else{
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details could not be found!");
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be found!");
		}
		return mv;
	
	}
	@RequestMapping(value="/logOut")
	
	public ModelAndView logOut(@ModelAttribute("user") User user) {
		ModelAndView mv = new ModelAndView("loginScreen", "user", user);
				return mv;
	}
}
	
	


