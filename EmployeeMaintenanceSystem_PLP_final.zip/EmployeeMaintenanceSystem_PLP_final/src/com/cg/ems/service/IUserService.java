package com.cg.ems.service;

import com.cg.ems.exception.EmployeeException;

public interface IUserService {
	
	String getRole(String username,String password) throws EmployeeException;
	
}
