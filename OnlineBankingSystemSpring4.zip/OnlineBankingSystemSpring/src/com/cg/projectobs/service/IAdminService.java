package com.cg.projectobs.service;

import java.util.List;

import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;

public interface IAdminService {

	public boolean login(String userName, String password) throws OnlineBankingException;
	public List<ServiceBean> viewAllServices()throws OnlineBankingException ;
	public int modifyRR(ServiceBean service)throws OnlineBankingException;
	public int modifych(ServiceBean service)throws OnlineBankingException;

	public List<TransactionBean> getData(String input) throws OnlineBankingException;
}
