package com.cg.projectobs.service;

import java.util.List;

import com.cg.projectobs.bean.AccountMasterBean;
import com.cg.projectobs.bean.CustomerBean;
import com.cg.projectobs.bean.FundTransferBean;
import com.cg.projectobs.bean.PayeeBean;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.bean.UserBean;
import com.cg.projectobs.exception.OnlineBankingException;

public interface ICustomerService {
	public boolean addCustomer(CustomerBean custbean,AccountMasterBean accountbean,UserBean userbean,ServiceBean service)throws OnlineBankingException;
	public UserBean login(int userId, String password)throws OnlineBankingException;
	public boolean addPayee(PayeeBean payee,int id)throws OnlineBankingException;
	public List<PayeeBean> viewAllPayees(int id)throws OnlineBankingException;
	public boolean transferAmountToBenificiary(PayeeBean payee,TransactionBean trans,FundTransferBean fund,int id)throws OnlineBankingException;
	public int modifyAddress(String address, int id)throws OnlineBankingException;
	public int checkBalance(int id)throws OnlineBankingException;
	public List<TransactionBean> viewMiniStatement(int id)throws OnlineBankingException;
	public boolean addChequeRequest(ServiceBean service,int id)throws OnlineBankingException;
	public int modifyPass(String password, int id)throws OnlineBankingException;
	public ServiceBean checkStatus(int id)throws OnlineBankingException;


}
