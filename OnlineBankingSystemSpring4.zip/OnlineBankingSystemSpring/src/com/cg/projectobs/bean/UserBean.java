package com.cg.projectobs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "user_table")
public class UserBean {

	@Id
	@NotNull(message = "Please enter only digits")
	@Column(name = "user_id")
	private int userId;
	@NotEmpty(message = "Password field cannot be empty!!")
	@Pattern(regexp = "^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$", message = "Password is not strong enough. At least 8 chars, At least one digit, At least one lower alpha char and one upper alpha char, At least one char within a set of special chars (@#%$^), Should not contain spaces and tabs")
	@Column(name = "login_password")
	private String loginPassword;
	@Column(name = "secret_question")
	private String secretQuestion;
	@NotEmpty(message = "Answer Cannot be empty")
	@Pattern(regexp = "^[#.0-9a-zA-Z\\s,-]+$", message = "Enter a valid movie name")
	@Column(name = "transaction_password")
	private String transactionPassword;
	@Column(name = "lock_status")
	private String lockStatus;
	@Column(name = "account_id")
	private int accountId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

}
