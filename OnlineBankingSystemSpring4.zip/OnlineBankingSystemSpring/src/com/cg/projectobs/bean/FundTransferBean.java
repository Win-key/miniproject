package com.cg.projectobs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="fund_transfer")
public class FundTransferBean {
	
	@Id
	@Column(name="fundtransfer_id")
	@SequenceGenerator(name = "fund_seq", sequenceName = "fund_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="fund_seq")
	private int fundTransferId;
	@Column(name="account_id")
	private int accountId;
	@Column(name="payee_account_id")
	private int payeeAccountId;
	@Column(name="date_of_transfer")
	private Date dateOfTranfer;
	@Column(name="transfer_amount")
	private int transferAmount;
	public int getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	public Date getDateOfTranfer() {
		return dateOfTranfer;
	}
	public void setDateOfTranfer(Date dateOfTranfer) {
		this.dateOfTranfer = dateOfTranfer;
	}
	public int getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(int transferAmount) {
		this.transferAmount = transferAmount;
	}
	
	
	

}
