package com.cg.projectobs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "payeetable")
public class PayeeBean {

	@Id
	@Column(name = "payee_account_id")
	private int payeeAccountId;
	@Column(name = "nick_name")
	@NotEmpty(message = "Nick name cannot be empty!!")
	@Pattern(regexp = "^[a-zA-Z]+$",message="Please enter only alphabets")
	private String nickName;

	@Column(name = "account_id")
	private int accountId;

	public int getPayeeAccountId() {
		return payeeAccountId;
	}

	public void setPayeeAccountId(int payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

}
