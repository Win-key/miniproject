package com.cg.projectobs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="users")
public class Login {
	@Id
	@NotEmpty(message="Field cannot be empty")
	@Pattern(regexp="^[a-zA-Z]+$",message="Please enter only alphabets")
	@Column(name="username")
	private String userName;
	@NotEmpty(message="Password cannot be empty!!!")
	@Column(name="password")
	private String password;
	@Column(name="role")
	private String role;
	
	public Login(){
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
}
