package com.cg.projectobs.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.projectobs.bean.AccountMasterBean;
import com.cg.projectobs.bean.CustomerBean;
import com.cg.projectobs.bean.FundTransferBean;
import com.cg.projectobs.bean.PayeeBean;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.bean.UserBean;


/*******************************************************************************************************
 * - Class Name : CustomerDaoImpl - Author : Swathi Anandram, Roshni P G -
 * Creation Date : 15/02/2018 - Description : Dao Layer for Customer
 ********************************************************************************************************/
@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {
	private static Logger log = Logger.getLogger(CustomerDaoImpl.class);

	public CustomerDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	@PersistenceContext
	private EntityManager entityManager;

	/*******************************************************************************************************
	 * - Function Name : addCustomer(CustomerBean custbean, AccountMasterBean
	 * accountbean, UserBean userbean, ServiceBean service) - Input Parameters :
	 * CustomerBean custbean, AccountMasterBean accountbean, UserBean userbean,
	 * ServiceBean service - Return Type : boolean - Throws :
	 * OnlineBankingException - Author : Swathi Anandram, Roshni P G - Creation
	 * Date : 15/02/2018 - Description : Add a new customer
	 ********************************************************************************************************/
	@Override
	public boolean addCustomer(CustomerBean custbean,
			AccountMasterBean accountbean, UserBean userbean,
			ServiceBean service) {
		log.debug("Add customer Called");
		accountbean.setOpenDate(Date.valueOf(LocalDate.now()));
		entityManager.persist(accountbean);
		custbean.setAccountId(accountbean.getAccountId());
		entityManager.persist(custbean);
		userbean.setAccountId(accountbean.getAccountId());
		userbean.setLockStatus("O");
		userbean.setSecretQuestion("Favouritemovie");
		entityManager.persist(userbean);
		service.setAccountId(accountbean.getAccountId());
		service.setServiceDescription("REGISTRATION REQUEST");
		service.setServiceRaisedDate(Date.valueOf(LocalDate.now()));
		service.setServiceStatus("PENDING");
		entityManager.persist(service);
		log.debug("Add customer Completed");
		return true;

	}

	/*******************************************************************************************************
	 * - Function Name : login(int userId, String password) - Input Parameters :
	 * int userId, String password - Return Type : UserBean - Throws :
	 * OnlineBankingException - Author : Swathi Anandram, Roshni P G - Creation
	 * Date : 15/02/2018 - Description : Login for Customer
	 ********************************************************************************************************/
	@Override
	public UserBean login(int userId, String password) {
		log.debug("User login Called");
		UserBean bean = entityManager.find(UserBean.class, userId);
		log.debug("User login completed");
		return bean;
	}

	/*******************************************************************************************************
	 * - Function Name : addPayee(PayeeBean payee, int id) - Input Parameters :
	 * PayeeBean payee, int id - Return Type : boolean - Throws :
	 * OnlineBankingException - Author : Swathi Anandram, Roshni P G - Creation
	 * Date : 15/02/2018 - Description : Adding a payee
	 ********************************************************************************************************/
	@Override
	public boolean addPayee(PayeeBean payee, int id) {
		log.debug("add payee started!!");
		payee.setAccountId(id);
		entityManager.persist(payee);
		log.debug("add payee completed!!");
		return true;

	}

	/*******************************************************************************************************
	 * - Function Name : viewAllPayees(int id) - Input Parameters : int id -
	 * Return Type : List<PayeeBean> - Throws : OnlineBankingException - Author
	 * : Swathi Anandram, Roshni P G - Creation Date : 15/02/2018 - Description
	 * : Viewing all payees
	 ********************************************************************************************************/
	@Override
	public List<PayeeBean> viewAllPayees(int id) {
		log.debug("view payee started!!");
		TypedQuery<PayeeBean> query = entityManager.createQuery(
				"FROM PayeeBean WHERE accountId=?", PayeeBean.class);
		query.setParameter(1, id);
		log.debug("view payee completed!!");
		return query.getResultList();

	}

	/*******************************************************************************************************
	 * - Function Name : transferAmountToBenificiary(PayeeBean payee,
	 * TransactionBean trans, FundTransferBean fund, int id) - Input Parameters
	 * : PayeeBean payee, TransactionBean trans, FundTransferBean fund, int id -
	 * Return Type : boolean - Throws : OnlineBankingException - Author : Swathi
	 * Anandram, Roshni P G - Creation Date : 15/02/2018 - Description :
	 * transfering amount to payee
	 ********************************************************************************************************/
	@Override
	public boolean transferAmountToBenificiary(PayeeBean payee,
			TransactionBean trans, FundTransferBean fund, int id) {
		log.debug("transfer amount to payee started!!");
		AccountMasterBean bean = new AccountMasterBean();
		TypedQuery<AccountMasterBean> query = entityManager.createQuery(
				"FROM AccountMasterBean WHERE accountId=?",
				AccountMasterBean.class);
		query.setParameter(1, id);
		bean = query.getSingleResult();
		System.out.println(trans.getTransactionAmount());
		System.out.println(bean.getAccountBalance());
		System.out.println(trans.getTransactionAmount());
		if ((bean.getAccountBalance() - trans.getTransactionAmount()) > 1000) {
			if (trans.getTransactionAmount() >= 100) {
				Query query1 = entityManager
						.createQuery("UPDATE AccountMasterBean SET accountBalance=? WHERE accountId=?");
				query1.setParameter(1, (bean.getAccountBalance() - trans
						.getTransactionAmount()));
				query1.setParameter(2, bean.getAccountId());
				query1.executeUpdate();

				TypedQuery<PayeeBean> query3 = entityManager.createQuery(
						"FROM PayeeBean WHERE accountId=? AND nickName=?",
						PayeeBean.class);
				query3.setParameter(1, bean.getAccountId());
				query3.setParameter(2, payee.getNickName());
				PayeeBean payee1 = query3.getSingleResult();

				trans.setAccountNo(id);
				trans.setDateofTransaction(Date.valueOf(LocalDate.now()));
				trans.setTransactionType("D");
				entityManager.persist(trans);

				fund.setAccountId(id);
				fund.setDateOfTranfer(Date.valueOf(LocalDate.now()));
				fund.setPayeeAccountId(payee1.getPayeeAccountId());
				fund.setTransferAmount(trans.getTransactionAmount());
				entityManager.persist(fund);
				log.debug("transfer amount to payee completed!!");
				return true;
			} else {
				log.debug("transfer amount to payee interrupted!!");
				return false;
			}
		} else {
			log.debug("transfer amount to payee interrupted!!");
			return false;
		}
	}

	/*******************************************************************************************************
	 * - Function Name : modifyAddress(String address, int id) - Input
	 * Parameters : String address, int id - Return Type : int - Throws :
	 * OnlineBankingException - Author : Swathi Anandram, Roshni P G - Creation
	 * Date : 15/02/2018 - Description : modify the address
	 ********************************************************************************************************/
	@Override
	public int modifyAddress(String address, int id) {
		log.debug("modify address started");
		Query query1 = entityManager
				.createQuery("UPDATE CustomerBean SET address=? WHERE accountId=?");
		query1.setParameter(1, address);
		query1.setParameter(2, id);
		int count = query1.executeUpdate();
		log.debug("modify address completed!!");
		return count;

	}

	/*******************************************************************************************************
	 * - Function Name : checkBalance(int id) - Input Parameters : int id -
	 * Return Type : int - Throws : OnlineBankingException - Author : Swathi
	 * Anandram, Roshni P G - Creation Date : 15/02/2018 - Description : check
	 * the balance in the account
	 ********************************************************************************************************/
	@Override
	public int checkBalance(int id) {
		log.debug("check balance started");
		AccountMasterBean bean = new AccountMasterBean();
		TypedQuery<AccountMasterBean> query = entityManager.createQuery(
				"FROM AccountMasterBean WHERE accountId=?",
				AccountMasterBean.class);
		query.setParameter(1, id);
		bean = query.getSingleResult();
		log.debug("check balance completed");
		return bean.getAccountBalance();
	}

	/*******************************************************************************************************
	 * - Function Name : viewMiniStatement(int id) - Input Parameters : int id -
	 * Return Type : List<TransactionBean> - Throws : OnlineBankingException -
	 * Author : Swathi Anandram, Roshni P G - Creation Date : 15/02/2018 -
	 * Description : view the mini statements
	 ********************************************************************************************************/
	@Override
	public List<TransactionBean> viewMiniStatement(int id) {
		log.debug("view mini statement started");
		TypedQuery<TransactionBean> query = entityManager
				.createQuery("FROM TransactionBean WHERE accountNo=?",
						TransactionBean.class);
		query.setParameter(1, id);
		log.debug("view mini statement completed");
		return query.getResultList();
	}

	/*******************************************************************************************************
	 * - Function Name : addChequeRequest(ServiceBean service, int id) - Input
	 * Parameters : ServiceBean service, int id - Return Type : boolean - Throws
	 * : OnlineBankingException - Author : Swathi Anandram, Roshni P G -
	 * Creation Date : 15/02/2018 - Description : Asking for cheque book
	 ********************************************************************************************************/
	@Override
	public boolean addChequeRequest(ServiceBean service, int id) {
		log.debug("ask for cheque book started");
		service.setServiceDescription("CHEQUE BOOK REQUEST");
		service.setAccountId(id);
		service.setServiceRaisedDate(Date.valueOf(LocalDate.now()));
		service.setServiceStatus("PENDING");
		entityManager.persist(service);
		log.debug("ask for cheque book completed");
		return true;
	}

	/*******************************************************************************************************
	 * - Function Name : modifyPass(String password, int id) - Input Parameters
	 * : String password, int id - Return Type : int - Throws :
	 * OnlineBankingException - Author : Swathi Anandram, Roshni P G - Creation
	 * Date : 15/02/2018 - Description : Modifying the password
	 ********************************************************************************************************/
	@Override
	public int modifyPass(String password, int id) {
		log.debug("modify password started");
		Query query1 = entityManager
				.createQuery("UPDATE UserBean SET loginPassword=? WHERE accountId=?");
		query1.setParameter(1, password);
		query1.setParameter(2, id);
		int count = query1.executeUpdate();
		log.debug("modify password completed");
		return count;
	}

	/*******************************************************************************************************
	 * - Function Name : checkStatus(int id) - Input Parameters : int id -
	 * Return Type : ServiceBean - Throws : OnlineBankingException - Author :
	 * Swathi Anandram, Roshni P G - Creation Date : 15/02/2018 - Description :
	 * Check the status of the cheque book request
	 ********************************************************************************************************/
	@Override
	public ServiceBean checkStatus(int id) {
		log.debug("check status started ");
		TypedQuery<ServiceBean> query = entityManager.createQuery(
				"FROM ServiceBean WHERE accountId=? AND serviceDescription=?",
				ServiceBean.class);
		query.setParameter(1, id);
		query.setParameter(2, "REGISTRATION REQUEST");
		log.debug("check status completed");
		return query.getSingleResult();
	}
}
