package com.cg.projectobs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.projectobs.bean.Login;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.exception.OnlineBankingException;


/*******************************************************************************************************
- Class Name	:	AdminDaoImpl
- Author		:	Swathi Anandram, Roshni P G
- Creation Date	:	15/02/2018
- Description	:	Dao Layer for Admin
********************************************************************************************************/
@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao{
	private static Logger log = Logger.getLogger(AdminDaoImpl.class);

	public AdminDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/*******************************************************************************************************
	 - Function Name	:	login(String username, String password)
	 - Input Parameters	:	String username, String password
	 - Return Type		:	boolean
	 - Throws			:  	OnlineBankingException
	 - Author			:	Swathi Anandram, Roshni P G
	 - Creation Date	:	15/02/2018
	 - Description		:	Login for Admin
	 ********************************************************************************************************/
	@Override
	public boolean login(String username, String password) {
		log.debug("Login admin started!!");
		Login bean = entityManager.find(Login.class,username);
		boolean flag = false;
		if(bean!=null){
			if(bean.getPassword().equals(password)){
				flag = true;
			}
			else{
				flag=false;
			}
		}
		log.debug("Login admin Completed");
		return flag;
	}
	/*******************************************************************************************************
	 - Function Name	:	getData(String input)
	 - Input Parameters	:	String input
	 - Return Type		:	List<TransactionBean>
	 - Throws			:  	OnlineBankingException
	 - Author			:	Swathi Anandram, Roshni P G
	 - Creation Date	:	15/02/2018
	 - Description		:	Listing the transactions
	 ********************************************************************************************************/

	@Override
	public List<TransactionBean> getData(String input)
			throws OnlineBankingException {
		log.debug("view transactions started!!");
		TypedQuery<TransactionBean> query = entityManager.createQuery("SELECT t FROM TransactionBean t WHERE to_char(dateOfTransaction,'DD-MM-YYYY') like :input", TransactionBean.class);
		query.setParameter("input", "%" + input);
		log.debug("view transactions completed!!");
		return query.getResultList();
	}

	/*******************************************************************************************************
	 - Function Name	:	viewAllServices()
	 - Input Parameters	:	void
	 - Return Type		:	List<ServiceBean>
	 - Throws			:  	OnlineBankingException
	 - Author			:	Swathi Anandram, Roshni P G
	 - Creation Date	:	15/02/2018
	 - Description		:	Listing the services
	 ********************************************************************************************************/
	@Override
	public List<ServiceBean> viewAllServices() {
		log.debug("view services started!!");
		TypedQuery<ServiceBean> query = entityManager.createQuery(
				"FROM ServiceBean", ServiceBean.class);
		log.debug("view services completed!!");
		return query.getResultList();
	}


	@Override
	public int modifyRR(ServiceBean service) {
		log.debug("Modify registration started!!");
		Query query1 = entityManager
				.createQuery("UPDATE ServiceBean SET serviceStatus=? WHERE serviceId=? AND serviceDescription=? AND serviceStatus=?");
		query1.setParameter(1, "ACTIVATED");
		query1.setParameter(2, service.getServiceId());
		query1.setParameter(3, "REGISTRATION REQUEST");
		query1.setParameter(4, "PENDING");
		
		int count=query1.executeUpdate();
		log.debug("Modify registration completed!!");
		return count;
	}


	@Override
	public int modifych(ServiceBean service) {
		log.debug("Modify cheque book started!!");
		Query query1 = entityManager
				.createQuery("UPDATE ServiceBean SET serviceStatus=? WHERE serviceId=? AND serviceDescription=? AND serviceStatus=?");
		query1.setParameter(1, "ACTIVATED");
		query1.setParameter(2, service.getServiceId());
		query1.setParameter(3, "CHEQUE BOOK REQUEST");
		query1.setParameter(4, "PENDING");
		
		int count=query1.executeUpdate();
		log.debug("Modify cheque book completed!!");
		return count;
	}

}
