package com.cg.projectobs.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.projectobs.bean.AccountMasterBean;
import com.cg.projectobs.bean.CustomerBean;
import com.cg.projectobs.bean.FundTransferBean;
import com.cg.projectobs.bean.PayeeBean;
import com.cg.projectobs.bean.ServiceBean;
import com.cg.projectobs.bean.TransactionBean;
import com.cg.projectobs.bean.UserBean;
import com.cg.projectobs.exception.OnlineBankingException;
import com.cg.projectobs.service.ICustomerService;
@Controller
@RequestMapping("*.cust")
public class Customer {
	@Autowired
	private ICustomerService custService;

	public ICustomerService getCustService() {
		return custService;
	}

	public void setCustService(ICustomerService custService) {
		this.custService = custService;
	}

	@RequestMapping("/backpage")
	public ModelAndView backpage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("backhomecust");
		return mv;

	}

	@RequestMapping("/newcust")
	public ModelAndView addcustomerr() {
		ModelAndView mv = new ModelAndView();
		CustomerBean customer = new CustomerBean();
		AccountMasterBean account = new AccountMasterBean();
		UserBean user = new UserBean();
		mv.addObject("customer", customer);
		mv.addObject("account", account);
		mv.addObject("user", user);
		mv.setViewName("addCustomer");
		return mv;

	}

	@RequestMapping(value = "/addcust", method = RequestMethod.POST)
	public ModelAndView newcustomer(
			@ModelAttribute("customer") @Valid CustomerBean customer,
			BindingResult result,
			@ModelAttribute("account") @Valid AccountMasterBean account,
			BindingResult result2,
			@ModelAttribute("user") @Valid UserBean user,
			BindingResult result3,
			@ModelAttribute("service") ServiceBean service) {
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors() && !result2.hasErrors()
					&& !result3.hasErrors()) {
				custService.addCustomer(customer, account, user, service);
				mv.addObject("id", account.getAccountId());
				mv.addObject("isFirst", true);
				mv.addObject("message",
						"Your details have been added successfully!!!Login Again to use our services!!");
				mv.setViewName("addCustomer");
			} else {
				mv.addObject("customer", customer);
				mv.addObject("account", account);
				mv.addObject("user", user);
				mv.addObject("isFirst", true);
				mv.addObject("message",
						"Your details are not added!!!Try Again!");
				mv.setViewName("addCustomer");

			}
		} catch (Exception e) {
			mv.addObject("customer", customer);
			mv.addObject("account", account);
			mv.addObject("user", user);
			mv.addObject("isFirst", true);
			mv.addObject("message", "User id is already taken!!! Choose a different one!!");
			mv.setViewName("addCustomer");
		}

		return mv;

	}

	@RequestMapping("/logincust")
	public ModelAndView existingCust() {
		UserBean login = new UserBean();
		return new ModelAndView("logincustomer", "login", login);
	}

	@RequestMapping("/loginValidateCust")
	public ModelAndView loginValidateCust(
			@ModelAttribute("login")UserBean login, BindingResult result,
			HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();

		try {
			if (!result.hasErrors()) {
				UserBean login1 = custService.login(login.getUserId(),
						login.getLoginPassword());
				if (login.getLoginPassword().equals(login1.getLoginPassword())) {
					request.getSession().setAttribute("id",
							login1.getAccountId());
					ServiceBean service1 = new ServiceBean();
					service1 = custService.checkStatus((int) request
							.getSession().getAttribute("id"));
					if (service1.getServiceStatus().equals("ACTIVATED")) {

						mv.addObject("login", login1);
						mv.setViewName("homecustomer");
					} else {
						mv.addObject("isFirst", false);
						mv.addObject("message",
								"Your Account is not yet Activated!!Please Contact Customer Care!!");
						mv.addObject("login", login);
						mv.setViewName("logincustomer");
					}

				} else {
					mv.addObject("isFirst", false);
					mv.addObject("message", "Login Failed");
					mv.addObject("login", login);
					mv.setViewName("logincustomer");
				}
			} else {
				mv.addObject("isFirst", false);
				mv.addObject("message", "Login Failed");
				mv.addObject("login", login);
				mv.setViewName("logincustomer");
			}
		} catch (Exception e) {
			mv.addObject("isFirst", false);
			mv.addObject("message",
					"Login Failed! Invalid UserId or Password!!");
			mv.addObject("login", login);
			mv.setViewName("logincustomer");
		}

		return mv;

	}

	@RequestMapping(value = "/addpayee", method = RequestMethod.POST)
	public ModelAndView addbeneficiary(
			@ModelAttribute("payee") PayeeBean payee,
			@ModelAttribute("login") UserBean login, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors()) {
				boolean flag = custService.addPayee(payee, (int) request
						.getSession().getAttribute("id"));
				if (flag == true) {
					// mv.addObject("isFirst", true);
					mv.addObject("message", "Payee Added Successfully!!");
					mv.setViewName("addpayee");
				} else {
					mv.addObject("isFirst", false);
					mv.addObject("message", "Payee Already Exists!!");
					mv.setViewName("addpayee");
				}
			} else {
				mv.addObject("isFirst", false);
				mv.addObject("message", "Payee Already Exists!!");
				mv.setViewName("addpayee");
			}
		} catch (OnlineBankingException e) {
			mv.addObject("isFirst", false);
			mv.addObject("message", "Payee Already Exists!!");
			mv.setViewName("addpayee");
		} catch (Exception e) {
			mv.addObject("isFirst", false);
			mv.addObject("message", "Payee Already Exists!!");
			mv.setViewName("addpayee");
		}

		return mv;
	}

	@RequestMapping("/addbeneficiary")
	public ModelAndView addpayee(@ModelAttribute("payee") PayeeBean payee,
			@ModelAttribute("login") UserBean login, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("payee", payee);
		request.getSession().getAttribute("id");
		mv.addObject("login", login);
		mv.setViewName("addpayee");

		return mv;
	}

	@RequestMapping("/viewbeneficiary")
	public ModelAndView viewBeneficiary(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		try {
			List<PayeeBean> list = custService.viewAllPayees((int) request
					.getSession().getAttribute("id"));
			if (list.isEmpty()) {
				mv.setViewName("homecustomer");
				mv.addObject("message", "No Payees!!");
				mv.addObject("vpayee", 1);
			} else {
				mv.addObject("list", list);
				mv.setViewName("viewAllPayees");

			}
		} catch (OnlineBankingException e) {
			mv.setViewName("homecustomer");
			mv.addObject("message", "No Payees!!");
			mv.addObject("vpayee", 1);
		}
		return mv;
	}

	@RequestMapping("/transfer")
	public ModelAndView transfer(@ModelAttribute("login") UserBean login,
			BindingResult result, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		request.getSession().getAttribute("id");
		PayeeBean payee = new PayeeBean();
		TransactionBean trans = new TransactionBean();
		FundTransferBean fund = new FundTransferBean();
		mv.setViewName("transfer");
		mv.addObject("payee", payee);
		mv.addObject("trans", trans);
		mv.addObject("fund", fund);
		return mv;

	}

	@RequestMapping("/transferpayee")
	public ModelAndView transferamount(
			@ModelAttribute("payee") PayeeBean payee,
			@ModelAttribute("trans") TransactionBean trans,
			@ModelAttribute("fund") FundTransferBean fund,
			@ModelAttribute("login") UserBean login, BindingResult result,
			HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();

		try {
			if (!result.hasErrors()) {
				boolean flag = custService.transferAmountToBenificiary(payee,
						trans, fund, (int) request.getSession().getAttribute("id"));
				if (flag == true) {
					mv.addObject("isFirst", true);
					mv.addObject("message", "Amount Transferred Successfully!!");
					mv.setViewName("transfer");
				} else {
					mv.setViewName("transfer");
					mv.addObject("payee", payee);
					mv.addObject("trans", trans);
					mv.addObject("fund", fund);
					mv.addObject("isFirst", false);
					mv.addObject("message", "Amount transfer failed!!");
				}
			} else {

				mv.setViewName("transfer");
				mv.addObject("payee", payee);
				mv.addObject("trans", trans);
				mv.addObject("fund", fund);
				mv.addObject("isFirst", false);
				mv.addObject("message", "Amount transfer failed!!");
			}
		} catch (Exception e) {
			mv.setViewName("transfer");
			mv.addObject("payee", payee);
			mv.addObject("trans", trans);
			mv.addObject("fund", fund);
			mv.addObject("isFirst", false);
			mv.addObject("message", "Payee does not exist");
		}

		return mv;

	}

	@RequestMapping("/updateaddress")
	public ModelAndView updateadd() {
		ModelAndView mv = new ModelAndView();
		CustomerBean customer = new CustomerBean();
		mv.addObject("customer", customer);
		mv.setViewName("updateaddress");
		return mv;

	}

	@RequestMapping("/modifyaddress")
	public ModelAndView Modify(
			@ModelAttribute("customer") CustomerBean customer,
			BindingResult result, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		try {
			if (!result.hasErrors()) {
				int id = custService.modifyAddress(customer.getAddress(),
						(int) request.getSession().getAttribute("id"));
				if (id > 0) {
					mv.setViewName("updateaddress");
					mv.addObject("message", "Updated Successfully!!");
					mv.addObject("isFirst", true);
				} else {
					mv.setViewName("updateaddress");
					mv.addObject("customer", customer);
					mv.addObject("message", "Updation not successful");
					mv.addObject("isFirst", false);

				}
			} else {
				mv.setViewName("updateaddress");
				mv.addObject("customer", customer);
				mv.addObject("message", "Updation not successful");
				mv.addObject("isFirst", false);
			}
		} catch (OnlineBankingException e) {
			mv.setViewName("updateaddress");
			mv.addObject("customer", customer);
			mv.addObject("message", "Updation not successful");
			mv.addObject("isFirst", false);
		}
		return mv;
	}

	@RequestMapping("/checkbalance")
	public ModelAndView check(
			@ModelAttribute("account") AccountMasterBean account,
			HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();
		try {
			int bal = custService.checkBalance((int) request.getSession()
					.getAttribute("id"));
			if (bal > 0) {
				mv.setViewName("homecustomer");
				mv.addObject("isFirst", true);
				mv.addObject("bal", bal);
			}
		} catch (OnlineBankingException e) {
			mv.setViewName("homecustomer");
			mv.addObject("isFirst", false);
			mv.addObject("message","nothing to display");
		}
		return mv;

	}

	@RequestMapping("/ministatement")
	public ModelAndView mini(HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();
		try {
			List<TransactionBean> list = custService
					.viewMiniStatement((int) request.getSession()
							.getAttribute("id"));
			if (list.isEmpty()) {
				mv.setViewName("ministatement");
				mv.addObject("message", "No Transaction");
				mv.addObject("isFirst", "1");
			} else {
				mv.addObject("list", list);
				mv.addObject("isFirst", "2");
				mv.setViewName("ministatement");

			}
		} catch (OnlineBankingException e) {
			mv.setViewName("ministatement");
			mv.addObject("message", "No Transaction");
			mv.addObject("isFirst", "1");
		}
		return mv;
	}

	@RequestMapping("/askforchbook")
	public ModelAndView chequebook(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		try {
			ServiceBean service = new ServiceBean();
			boolean flag = custService.addChequeRequest(service, (int) request
					.getSession().getAttribute("id"));
			if (flag == true) {
				mv.setViewName("homecustomer");
				mv.addObject("power", 3);
				mv.addObject("message", "Cheque Book Request Successful!!");
			} else {
				mv.setViewName("homecustomer");
				mv.addObject("power", 4);
				mv.addObject("message", "Cheque Book Request Failed!!");
			}
		} catch (OnlineBankingException e) {
			mv.setViewName("homecustomer");
			mv.addObject("power", 4);
			mv.addObject("message", "Cheque Book Request Failed!!");
		}
		return mv;
	}

	@RequestMapping("/updateloginpass")
	public ModelAndView updatepass() {
		ModelAndView mv = new ModelAndView();
		UserBean user = new UserBean();
		mv.addObject("user", user);
		mv.setViewName("updatepassword");
		return mv;

	}

	@RequestMapping("/modifypass")
	public ModelAndView Modifypass(@ModelAttribute("user") UserBean user,
			BindingResult result, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();

		try {
			int id = custService.modifyPass(user.getLoginPassword(), (int) request
					.getSession().getAttribute("id"));
			if (id > 0) {
				mv.setViewName("updatepassword");
				mv.addObject("message", "Updated Successfully!!");
				mv.addObject("isFirst", true);
			} else {
				mv.setViewName("updatepassword");
				mv.addObject("user", user);
				mv.addObject("message", "Updation not successful");
				mv.addObject("isFirst", false);

			}
		} catch (OnlineBankingException e) {
			mv.setViewName("updatepassword");
			mv.addObject("user", user);
			mv.addObject("message", "Updation not successful");
			mv.addObject("isFirst", false);
		}

		return mv;
	}

	@RequestMapping("/getchequestatus")
	public ModelAndView checkstatus(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		try {
			ServiceBean bean = new ServiceBean();
			bean = custService.checkStatus((int) request.getSession().getAttribute(
					"id"));
			mv.setViewName("homecustomer");
			mv.addObject("bean", bean);
			mv.addObject("status", 1);
		} catch (OnlineBankingException e) {
			mv.setViewName("homecustomer");
			mv.addObject("status", 100);
			mv.addObject("message", "nothing to display");
		}
		return mv;

	}

}
