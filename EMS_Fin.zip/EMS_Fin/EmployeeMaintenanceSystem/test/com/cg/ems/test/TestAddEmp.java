package com.cg.ems.test;

import static org.junit.Assert.assertEquals;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.exception.EmployeeException;

public class TestAddEmp {

	
	@Test
	public void addEmpTest() throws EmployeeException{
		
		AdminDaoImpl dao = new AdminDaoImpl();
		Employee bean = new Employee();
		try {
			bean.setEmpFirstName("Vivin");
			bean.setEmpID("e109");
			bean.setEmpLastName("Christoper");
			DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
			Date dateofBirth = d.parse("02-04-1996");
			Date dateofJoining = d.parse("13-12-2017");
			bean.setEmpDateOfBirth(dateofBirth);
			bean.setEmpDateOfJoining(dateofJoining);
			bean.setEmpDeptId(1);
			bean.setEmpGrade("M3");
			bean.setEmpDesignation("Sales man");
			bean.setEmpBasic(20000.00);
			bean.setEmpGender("M");
			bean.setEmpMaritalStatus("Single");
			bean.setEmpHomeAddress("Chennai");
			bean.setEmpContactNum("9638527410");
			bean.setManagerId("e101");
	
			assertEquals(1, (long)dao.AddEmployee(bean));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
		}
	
	
}
