package com.cg.ems.test;


import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.User;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.UserDaoImpl;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class TestUser {
	
	@Test
	public void login() throws EmployeeException{
		UserDaoImpl dao1 = new UserDaoImpl();
		User user= (dao1.getUserByName("emp1"));
		Assert.assertNotNull(user);
	}
	
	
	
	
	
	/*@AfterClass
	public static void delete() throws EmployeeException{
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement st = con.prepareStatement("DELETE FROM employee where Emp_Id=?");
			st.setString(1,"e109");
			st.executeQuery();
			if(con!=null && !con.isClosed())
				con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
}	
	
