package com.cg.ems.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class TestApproveLeave {

	@Test
	public void approveLeave() {
		EmployeeDaoImpl empDao = new EmployeeDaoImpl();
		try {
			
			int count = empDao.approveLeave("e103", "e101", 1);
			assertEquals(1, count);
			
			Connection con = DBConnection.getConnection();
			PreparedStatement st = con.prepareStatement("DELETE FROM leave_history where Emp_Id=?");
			st.setString(1,"e103");
			st.executeQuery();
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
