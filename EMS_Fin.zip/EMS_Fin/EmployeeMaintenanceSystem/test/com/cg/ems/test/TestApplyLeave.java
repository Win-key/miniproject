package com.cg.ems.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.ems.bean.LeaveBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.exception.EmployeeException;

public class TestApplyLeave {

	@Test
	public void applyLeave() {
		EmployeeDaoImpl empDao = new EmployeeDaoImpl();
		LeaveBean leave = new LeaveBean();
		
		try {
			DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
			Date from_date = d.parse("12-02-2018");
			Date to_date = d.parse("10-02-2018");
			leave.setEmp_id("e103");
			leave.setNoofdays_applied(2);
			leave.setDate_from(from_date);
			leave.setDate_to(to_date);
			
			int count = empDao.applyLeave(leave);
			assertEquals(1, count);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}
