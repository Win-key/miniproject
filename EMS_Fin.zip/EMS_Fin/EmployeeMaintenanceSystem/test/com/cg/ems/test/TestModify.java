package com.cg.ems.test;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class TestModify {
	
	@Test
	public void modifyEmpTest() throws EmployeeException{
		
		AdminDaoImpl dao = new AdminDaoImpl();
		Employee bean = new Employee();
		
		try {
			bean.setEmpFirstName("Navin");
			bean.setEmpID("e109");
			bean.setEmpLastName("Christopher");
			DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
			Date dateofBirth = d.parse("02-04-1996");
			Date dateofJoining = d.parse("13-12-2017");
			bean.setEmpDateOfBirth(dateofBirth);
			bean.setEmpDateOfJoining(dateofJoining);
			bean.setEmpDeptId(1);
			bean.setEmpGrade("M3");
			bean.setEmpDesignation("Sales man");
			bean.setEmpBasic(30000.00);
			bean.setEmpGender("M");
			bean.setEmpMaritalStatus("Married");
			bean.setEmpHomeAddress("Chennai");
			bean.setEmpContactNum("9638527410");
			bean.setManagerId("e101");
			
			assertEquals(1, dao.modifyEmployee(bean));
		
			Connection con = DBConnection.getConnection();
			PreparedStatement st = con.prepareStatement("DELETE FROM employee where Emp_Id=?");
			st.setString(1,"e109");
			st.executeQuery();
			
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
