package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBConnection;

public class AdminDaoImpl implements IAdminDao{
	
	static Logger log =  Logger.getLogger(AdminDaoImpl.class.getName());
	
	
	
	public AdminDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	Connection con = null;
	@Override
	public int AddEmployee(Employee employee) throws EmployeeException {
		int count=0;
		
		String query=IQueryMapper.ADD_EMPLOYEE_QUERY;
		con=DBConnection.getConnection();
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1,employee.getEmpID());
			pstmt.setString(2,employee.getEmpFirstName());
			pstmt.setString(3, employee.getEmpLastName());
			Date edoB=employee.getEmpDateOfBirth();
			Date edoj=employee.getEmpDateOfJoining();
			java.sql.Date dob=new java.sql.Date(edoB.getTime());
			java.sql.Date doj=new java.sql.Date(edoj.getTime());
			pstmt.setDate(4, dob);
			pstmt.setDate(5, doj);
			pstmt.setInt(6, employee.getEmpDeptId());
			pstmt.setString(7, employee.getEmpGrade());
			pstmt.setString(8, employee.getEmpDesignation());
			pstmt.setDouble(9, employee.getEmpBasic());
			pstmt.setString(10, employee.getEmpGender());
			pstmt.setString(11, employee.getEmpMaritalStatus());
			pstmt.setString(12, employee.getEmpHomeAddress());
			pstmt.setString(13, employee.getEmpContactNum());
			pstmt.setString(14, employee.getManagerId());
			
			count = pstmt.executeUpdate();
			if(count>0)
			{
				log.info("ADDED SUCCESSFULLY");
				return count;
			}
			
		} catch (SQLException e) {
			log.debug(e.getMessage());
			throw new EmployeeException("You might be adding same employee ID or Manager ID not found in employee table"+e.getMessage());
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				log.debug(e.getMessage());
				throw new EmployeeException("Sorry!! Unable to close the connection " + e.getMessage());
			}
		}
		return count;
	}

	@Override
	public int modifyEmployee(Employee employee) throws EmployeeException {
		int count=0;
		String query=IQueryMapper.UPDATE_EMPLOYEE_QUERY;
		con = DBConnection.getConnection();
		
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1,employee.getEmpFirstName());
			pstmt.setString(2, employee.getEmpLastName());
			Date edoB=employee.getEmpDateOfBirth();
			Date edoj=employee.getEmpDateOfJoining();
			java.sql.Date dob=new java.sql.Date(edoB.getTime());
			java.sql.Date doj=new java.sql.Date(edoj.getTime());
			pstmt.setDate(3, dob);
			pstmt.setDate(4, doj);
			pstmt.setInt(5, employee.getEmpDeptId());
			pstmt.setString(6, employee.getEmpGrade());
			pstmt.setString(7, employee.getEmpDesignation());
			pstmt.setDouble(8, employee.getEmpBasic());
			pstmt.setString(9, employee.getEmpGender());
			pstmt.setString(10, employee.getEmpMaritalStatus());
			pstmt.setString(11, employee.getEmpHomeAddress());
			pstmt.setString(12, employee.getEmpContactNum());
			pstmt.setString(13, employee.getManagerId());
			pstmt.setString(14,employee.getEmpID());
			
			count = pstmt.executeUpdate();
			if(count>0)
			{	
				log.info("UPDATED SUCCESSFULLY");
				return count;
			}
		} catch (SQLException e) {
			log.debug(e.getMessage());
			throw new EmployeeException(e.getMessage());
			
		}
		
		
		
		return count;
	}

	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		List<Employee> list= new ArrayList<Employee>();
		con=DBConnection.getConnection();
		String query=IQueryMapper.VIEW_ALL_EMPLOYEES;
		
		try {
			PreparedStatement pstmt=con.prepareStatement(query);
			ResultSet result=pstmt.executeQuery();
			while(result.next())
			{
				Employee employee=new Employee();
				employee.setEmpID(result.getString("Emp_ID"));
				employee.setEmpFirstName(result.getString("Emp_First_Name"));
				employee.setEmpLastName(result.getString("Emp_Last_Name"));
				java.util.Date birthDate = new Date(result.getDate("Emp_Date_of_Birth").getTime());
				employee.setEmpDateOfBirth(birthDate);
				java.util.Date joinDate = new Date(result.getDate("Emp_Date_of_Joining").getTime());
				employee.setEmpDateOfJoining(joinDate);
				employee.setEmpDeptId(result.getInt("Emp_Dept_ID"));
				employee.setEmpGrade(result.getString("Emp_Grade"));
				employee.setEmpDesignation(result.getString("Emp_Designation"));
				employee.setEmpBasic(result.getDouble("Emp_Basic"));
				employee.setEmpGender(result.getString("Emp_Gender"));
				employee.setEmpMaritalStatus(result.getString("Emp_Marital_Status"));
				employee.setEmpHomeAddress(result.getString("Emp_Home_Address"));
				employee.setEmpContactNum(result.getString("Emp_Contact_Num"));
				employee.setManagerId(result.getString("Mgr_Id"));
				
				list.add(employee);
			}
			log.info("LISTED SUCCESSFULLY");
		} catch (SQLException e) {
			log.debug(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		
		return list;
	}

}
