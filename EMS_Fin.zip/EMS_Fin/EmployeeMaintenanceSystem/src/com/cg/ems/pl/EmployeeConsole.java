package com.cg.ems.pl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.LeaveBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class EmployeeConsole {

	IEmployeeService service = new EmployeeServiceImpl();
	private String userName;
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy");
	Date date;

	public EmployeeConsole(String userName) {
		this.userName = userName;
	}

	public void start() {
		System.out.println("Welcome " + userName);
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println("*******************************************************");
			System.out
					.println("1.Search by id \n2.Search by First name \n3.Search by Last Name\n4."
							+ "Search by department \n5.Search by Grade \n6.Search by marital status\n"
							+ "7.Apply Leave \n8.Approve leave by Manager  \n9.Approve on the Third day\n10.Exit");
			int key = scanner.nextInt();
			scanner.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter the employee id to be searched");
				try {
					Employee emp = new Employee();
					emp=service.searchById(scanner.nextLine());
					if(emp.getEmpDeptId()!=0){
					System.out.println("Employee details are:");
					System.out.println("*************************");
					System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
							+ emp.getEmpFirstName()+"\nLast Name: "
							+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
							+ emp.getEmpGrade()+"\nDesignation: "+emp.getEmpDesignation()+"\nMarital Status: "
							+ emp.getEmpMaritalStatus());
					}
					else{
						System.out.println("Sorry!The employee you are searching doesn't exist");
					}
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching the employee!!" + e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter first name of the employees to be search");
				try {
					List<Employee> list = service
							.searchByFN(scanner.nextLine());
					
					if (!list.isEmpty()) {
						System.out.println("Employee details are:");
						
						
						for (Employee emp : list) {
							System.out.println("*************************");
							String date1 = dateFormat.format(emp.getEmpDateOfBirth());
							String date2= dateFormat
									.format(emp.getEmpDateOfJoining());
							System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
									+ emp.getEmpFirstName()+"\nLast Name: "
									+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
									+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
									+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
						}
						System.out.println("*************************");
					}else{
						System.out.println("Sorry!!No employee exists as such!");
					}
					
					
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching employees!!" + e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}

				break;
			case 3:
				System.out.println("Enter last name of the employees to be searched");
				try {
					List<Employee> list = service
							.searchByLN(scanner.nextLine());
					if(!list.isEmpty()){
						System.out.println("Employee details are:");
					for (Employee emp : list) {
						System.out.println("*************************");
						String date1 = dateFormat.format(emp.getEmpDateOfBirth());
						String date2 = dateFormat
								.format(emp.getEmpDateOfJoining());
						System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
								+ emp.getEmpFirstName()+"\nLast Name: "
								+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
								+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
								+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
					}
					System.out.println("*************************");
					}
					else{
						System.out.println("Sorry!!No employee exists as such!");
					}
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching employees!!" + e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;

			case 4:
				System.out.println("Enter Department id of the employees to be searched");
				try {
					List<Employee> list = service.searchByDepId(scanner
							.nextInt());
					scanner.nextLine();
					if(!list.isEmpty()){
						System.out.println("Employee details are:");
					for (Employee emp : list) {
					
						System.out.println("*************************");
						String date1 = dateFormat.format(emp.getEmpDateOfBirth());
						String date2 = dateFormat
								.format(emp.getEmpDateOfJoining());
						System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
								+ emp.getEmpFirstName()+"\nLast Name: "
								+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
								+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
								+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
					}
					System.out.println("*************************");
					}
					else{
						System.out.println("Sorry!!No employee exists as such!");
					}
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching employees!!" + e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;

			case 5:
				System.out.println("Enter Grade of the employees to be searched");
				try {
					List<Employee> list = service.searchByGrade(scanner
							.nextLine());
					if(!list.isEmpty()){
						System.out.println("Employee details are:");
					for (Employee emp : list) {
						
						System.out.println("*************************");
						String date1 = dateFormat.format(emp.getEmpDateOfBirth());
						String date2 = dateFormat
								.format(emp.getEmpDateOfJoining());
						System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
								+ emp.getEmpFirstName()+"\nLast Name: "
								+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
								+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
								+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
					}
					System.out.println("*************************");
					}
					else{
						System.out.println("Sorry!!No employee exists as such!");
					}
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching employees!!" + e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}
				break;
			case 6:
				System.out.println("Enter marital status of the employees to be searched");
				try {
					List<Employee> list = service.searchByMarital(scanner
							.nextLine());
					if(!list.isEmpty()){
						System.out.println("Employee details are:");
					for (Employee emp : list) {
						System.out.println("*************************");
						String date1 = dateFormat.format(emp.getEmpDateOfBirth());
						String date2 = dateFormat
								.format(emp.getEmpDateOfJoining());
						System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
								+ emp.getEmpFirstName()+"\nLast Name: "
								+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
								+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
								+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
					}
					System.out.println("*************************");
					}
					else{
						System.out.println("Sorry!!No employee exists as such!");
					}
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while searching employees!!"+ e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}
				break;

			case 7:
				try {
					LeaveBean leave = new LeaveBean();
					System.out.println("Enter your employee ID");
					leave.setEmp_id(scanner.nextLine());
					System.out
							.println("Enter No of leave you are going to apply");
					leave.setNoofdays_applied(scanner.nextInt());
					scanner.nextLine();
					System.out.println("Leave starts from:");
					String Df = scanner.nextLine();
					Date dateFrom = dateFormat.parse(Df);
					leave.setDate_from(dateFrom);
					System.out.println("Leave ends on:");
					String Dt = scanner.nextLine();
					Date dateTo = dateFormat.parse(Dt);
					leave.setDate_to(dateTo);
					int count = service.applyLeave(leave);
					if (count > 0) {
						System.out.println("Leave applied successfully!!!");
					}else{
						System.out.println("Sorry!! You have insuficient leave balance");
					}
				} catch (ParseException e) {
					System.out.println("Please enter the date in the correct format");
				} catch (EmployeeException e) {
					System.out.println("Sorry!Exception occured while applying leave."+ e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}
				break;

			case 8:
				
				System.out.println("Enter the manager id");
				String managerId = scanner.nextLine();
				System.out.println("Enter the employee id");
				String employeeId = scanner.nextLine();
				System.out.println("Enter your action on leave \n1.Approve \n2.Reject");
				int action = scanner.nextInt();scanner.nextLine();
				try {
					int count = service.approveLeave(employeeId, managerId,action);
					if (count>0) {
						System.out.println("Leave approved successfully");
					}else{
						System.out.println("Leave rejected");
					}
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}
				break;
				
			case 9:
				System.out.println("Please Enter your Employee ID");
				String employeeId1 = scanner.nextLine();
				int count = 0;
				try {
					count = service.approveOnThird(employeeId1);
					if (count>0) {
						System.out.println("Leave approved successfully");
					}else {
						System.out.println("Kindly wait for three days to your leave get approved.");
					}
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;
			case 10:
				System.out.println("***************THANK YOU!*************");
				scanner.close();
				System.exit(1);
				break;

			}
		}
	}

}
