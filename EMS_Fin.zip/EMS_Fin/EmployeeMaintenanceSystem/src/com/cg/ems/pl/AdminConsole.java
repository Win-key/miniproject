package com.cg.ems.pl;




import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;






import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.IAdminService;

public class AdminConsole {

	private IAdminService aService=new AdminServiceImpl();
	private String userName;
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
	Date date;

	public AdminConsole(String userName) {
		
		this.userName = userName;
	}
	
	
	public void start()
	{
		Scanner scanner=new Scanner(System.in);
		while(true)
		{
			System.out.println("*****************************************************");
			System.out.println("1.Add the employee");
			System.out.println("2.Update the Employee details");
			System.out.println("3.View all employees");
			System.out.println("4.exit");
			System.out.println("Please enter the choice");
			int choice=scanner.nextInt();scanner.nextLine();
			switch(choice)
			{
			case 1:
				try {
					
				System.out.println("Enter the employee details");
				System.out.println("Enter the unique employee id");
				String empId=scanner.nextLine();
				System.out.println("Enter the employee First Name");
				String firstName = scanner.nextLine();
				System.out.println("Enter the employee last name");
				String lastName = scanner.nextLine();

				System.out.println("Enter the employee date of birth");
				String date = scanner.next();

				System.out.println("Enter the employee date of joining");
				String joinDate = scanner.next();
				
					DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
					Date dateofBirth = d.parse(date);
					Date dateofJoining = d.parse(joinDate);

					System.out.println("Enter the department id");
					int deptId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter the grade");
					String grade = scanner.nextLine();
					System.out.println("Enter the designation");
					String designation = scanner.nextLine();
					System.out.println("Enter the Basic salary");
					double basic = scanner.nextDouble();
					scanner.nextLine();
					System.out.println("Enter the gender");
					String gender = scanner.nextLine();
					System.out.println("Enter the marital status");
					String status = scanner.nextLine();
					System.out.println("enter the address");
					String address = scanner.nextLine();
					System.out.println("Enter the employee number");
					String number = scanner.nextLine();
					System.out.println("Enter the manager id");
					String managerId = scanner.nextLine();

					Employee emp = new Employee();
					emp.setEmpID(empId);
					emp.setEmpFirstName(firstName);
					emp.setEmpLastName(lastName);
					emp.setEmpDateOfBirth(dateofBirth);
					emp.setEmpDateOfJoining(dateofJoining);
					emp.setEmpDeptId(deptId);
					emp.setEmpGrade(grade);
					emp.setEmpDesignation(designation);
					emp.setEmpBasic(basic);
					emp.setEmpGender(gender);
					emp.setEmpMaritalStatus(status);
					emp.setEmpHomeAddress(address);
					emp.setEmpContactNum(number);
					emp.setManagerId(managerId);
				
					int result=aService.AddEmployee(emp);
					if(result>0)
					{
						System.out.println("Employee details added successfully!!");
					}
					else
					{
						System.out.println("Sorry!!Couldn't add employee details successfully!!");
					}
				}catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				} 
				catch (EmployeeException e) {
					System.err.println("Exception occurred:Sorry!!Couldn't add employee details successfully!!"+e.getMessage());
				} catch (ParseException e) {
					System.err.println("please enter the date in the required format");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
			break;
			case 2:
				try {
				System.out.println("Enter the employee details");
				System.out.println("Enter the unique employee id");
				String employeeId=scanner.nextLine();
				System.out.println("Enter the employee First Name");
				String fName = scanner.nextLine();
				System.out.println("Enter the employee last name");
				String lName = scanner.nextLine();

				System.out.println("Enter the employee date of birth");
				String birthDate = scanner.next();

				System.out.println("Enter the employee date of joining");
				String joinDate2 = scanner.next();
				
					DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
					Date dateofBirth = d.parse(birthDate);
					Date dateofJoining = d.parse(joinDate2);

					System.out.println("Enter the department id");
					int deptId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter the grade");
					String grade = scanner.nextLine();
					System.out.println("Enter the designation");
					String designation = scanner.nextLine();
					System.out.println("Enter the Basic salary");
					double basic = scanner.nextDouble();
					scanner.nextLine();
					System.out.println("Enter the gender");
					String gender = scanner.nextLine();
					System.out.println("Enter the marital status");
					String status = scanner.nextLine();
					System.out.println("enter the address");
					String address = scanner.nextLine();
					System.out.println("Enter the employee number");
					String number = scanner.nextLine();
					System.out.println("Enter the manager id");
					String managerId = scanner.nextLine();

					Employee emp = new Employee();
					emp.setEmpID(employeeId);
					emp.setEmpFirstName(fName);
					emp.setEmpLastName(lName);
					emp.setEmpDateOfBirth(dateofBirth);
					emp.setEmpDateOfJoining(dateofJoining);
					emp.setEmpDeptId(deptId);
					emp.setEmpGrade(grade);
					emp.setEmpDesignation(designation);
					emp.setEmpBasic(basic);
					emp.setEmpGender(gender);
					emp.setEmpMaritalStatus(status);
					emp.setEmpHomeAddress(address);
					emp.setEmpContactNum(number);
					emp.setManagerId(managerId);
				
					int result=aService.modifyEmployee(emp);
					if(result>0)
					{
						System.out.println("Employee details updated successfully!!");
					}
					else
					{
						System.out.println("Sorry!Failed to update the employee details!!");
					}
				} catch (InputMismatchException e) {
					System.err.println("Input type mismatched. Please enter the details in right formate");
				}catch (EmployeeException e) {
					System.err.println("Exception : Employee updation Failed "+e.getMessage());
				} catch (ParseException e) {
					System.err.println("Please enter the date in the required format");
				}catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				List<Employee> list= new ArrayList<Employee>();
				try {
					list=aService.viewAllEmployees();
					if(!list.isEmpty())
					{
						for(Employee emp:list)
						{
							System.out.println("*************************");
							String date1 = dateFormat.format(emp.getEmpDateOfBirth());
							String date2 = dateFormat
									.format(emp.getEmpDateOfJoining());
							System.out.println("ID: "+emp.getEmpID()+"\nFirst Name: "
									+ emp.getEmpFirstName()+"\nLast Name: "
									+ emp.getEmpLastName()+"\nDepartment ID: "+emp.getEmpDeptId()+"\nGrade: "
									+ emp.getEmpGrade()+"\nDesignation:"+emp.getEmpDesignation()+"\nMarital Status: "
									+ emp.getEmpMaritalStatus()+"\nDate of birth: "+date1+"\nDate of joining: "+date2);
						}
					}
				} catch (EmployeeException e) {
					System.err.println("Exception : Sorry!! Employees not found!! "+e.getMessage());
				}
				break;
				
			case 4:
				System.out.println("***************THANK YOU!*************");
				scanner.close();
				System.exit(0);
			break;
			}
			
			
			
			
		}
			
		
	}
	
	
	
}
