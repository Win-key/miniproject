package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.LeaveBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService {

	public Employee searchById(String id) throws EmployeeException;
	public List<Employee> searchByFN(String fName) throws EmployeeException;
	public List<Employee> searchByLN(String fName) throws EmployeeException;
	public List<Employee> searchByDepId(int dept) throws EmployeeException;
	public List<Employee> searchByGrade(String grade) throws EmployeeException;
	public List<Employee> searchByMarital(String marital) throws EmployeeException;
	
	public int applyLeave(LeaveBean leave) throws EmployeeException;
	public int approveLeave(String empId , String mgrId, int action) throws EmployeeException;
	public int approveOnThird(String empId) throws EmployeeException;
	
}
