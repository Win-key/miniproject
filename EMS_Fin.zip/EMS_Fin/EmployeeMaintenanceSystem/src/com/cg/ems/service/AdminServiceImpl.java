package com.cg.ems.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.IAdminDao;
import com.cg.ems.exception.EmployeeException;

public class AdminServiceImpl implements IAdminService{
	
	IAdminDao dao= new AdminDaoImpl();
	
	@Override
	public int AddEmployee(Employee employee) throws EmployeeException {
		
		validateEmployeeDetails(employee);
		
		return dao.AddEmployee(employee);
	}

	@Override
	public int modifyEmployee(Employee employee) throws EmployeeException {
		
		validateEmployeeDetails(employee);
		
		return dao.modifyEmployee(employee);
	}

	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		
		return dao.viewAllEmployees();
	}

	public void validateEmployeeDetails(Employee bean) throws EmployeeException{

		if(!(isValidId(bean.getEmpID()))) {
			throw new EmployeeException("\n Employee Id Should not be empty and should be a new ID with length of at most 6 \n");
		}

		else if(!(isValidFirstName(bean.getEmpFirstName()))) {
			throw new EmployeeException("\n Employee Name should be alphabetics and starting with upper case!  \n");
		}
		else if(!(isValidLastName(bean.getEmpLastName()))) {
			throw new EmployeeException("\n Employee Name should be alphabetics and starting with upper case  !  \n");
		}
		else if(!(isValidDateOfBirth(bean.getEmpDateOfBirth()))) {
			throw new EmployeeException("\n Employee Date of birth should be in date format! \n");
		}
		else if(!(isValidDateOfJoining(bean.getEmpDateOfJoining()))) {
			throw new EmployeeException("\n Employee  Date of joining should be in date format! \n");
		}
		else if(!(isValidDesignation(bean.getEmpDesignation()))) {
			throw new EmployeeException("\n Employee Designation should not be empty, should start with uppercase and should contains alphabetics ! \n");
		}
		else if(!(isValidGender(bean.getEmpGender()))) {
			throw new EmployeeException("\n Employee Gender should be M or F ! \n");
		}
		else if(!(isValidContactNumber(bean.getEmpContactNum()))) {
			throw new EmployeeException("\n Employee Contact number is not properly given ! \n");
		}
		else if(!(isValidHomeAddress(bean.getEmpHomeAddress()))) {
			throw new EmployeeException("\n Employee home address is not properly given ! \n");
		}
		else if(!(isValidMStatus(bean.getEmpMaritalStatus()))) {
			throw new EmployeeException("\n Employee marital status should not be empty and should be either Single or Married or Separated or Divorced or Widowed ! \n");
		}
		
		else if(!(isValidGrade(bean.getEmpGrade()))) {
			throw new EmployeeException("\n Employee grade should not be empty And should be in M1 to M7  ! \n");
		}
		else if(!(isValidBsalary(bean.getEmpGrade(),bean.getEmpBasic()))) {
			throw new EmployeeException("\n Employee grade and basic salary range should match ! \n");
		}

		
	}
		public boolean isValidId(String Id) {
		
		Pattern idPattern = Pattern.compile("[a-zA-Z0-9]+");
		Matcher idMatcher = idPattern.matcher(Id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	
	public boolean isValidFirstName(String firstName) {
		Pattern namePattern=Pattern.compile("^[A-Z]{1}[a-z]*$");
		Matcher nameMatcher=namePattern.matcher(firstName);
		return nameMatcher.matches();
	}
	public boolean isValidLastName(String lastName) {
		Pattern namePattern=Pattern.compile("^[A-Z]{1}[a-z]*$");
		Matcher nameMatcher=namePattern.matcher(lastName);
		return nameMatcher.matches();
	}
	public boolean isValidDateOfBirth(Date date)
	{
	
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
		 String strDate = formatter.format(date);  
		Pattern namePattern=Pattern.compile("([0-9]{2})-([0-9]{2})-([0-9]{4})");
		Matcher nameMatcher=namePattern.matcher(strDate);
		return nameMatcher.matches();
		
	}
	
	public boolean isValidDateOfJoining(Date date)
	{
	
		 SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");  
		 String strDate = formatter.format(date);  
		Pattern namePattern=Pattern.compile("([0-9]{2})-([0-9]{2})-([0-9]{4})");
		Matcher nameMatcher=namePattern.matcher(strDate);
		return nameMatcher.matches();
		
	}
	public boolean isValidAge(Date date,Date date1) {
		
		boolean flag=false;
				
				long dur  =date1.getTime() - date.getTime();
				long days=TimeUnit.DAYS.convert(dur, TimeUnit.MILLISECONDS);
				long duration=(days/365);
				if(duration>=18 && duration<=58)
				{
					flag=true;
				}
				
				return flag;
		}
	
	public boolean isValidDesignation(String designation) {
		Pattern namePattern=Pattern.compile("^[A-Za-z\\s]{1,50}$");
		Matcher nameMatcher=namePattern.matcher(designation);
		return nameMatcher.matches();
	}
	public boolean isValidGender(String gender) {
		
	if((gender!=null)&&(gender.equalsIgnoreCase("M")||gender.equalsIgnoreCase("F")))
				return true;
			else
				return false;
		}
	public boolean isValidContactNumber(String contactno) {
		Pattern namePattern=Pattern.compile("^[6-9][0-9]{9}$");
		Matcher nameMatcher=namePattern.matcher(contactno);
		return nameMatcher.matches();
	}
	public boolean isValidHomeAddress(String address) {
		Pattern namePattern=Pattern.compile("^[A-Za-z0-9\\,\\s\\.]*$");
		Matcher nameMatcher=namePattern.matcher(address);
		return nameMatcher.matches();
	}
	public boolean isValidMStatus(String mstat) {
	if((mstat!=null)&&(mstat.equalsIgnoreCase("Single")||mstat.equalsIgnoreCase("Married")||mstat.equalsIgnoreCase("Separated")||mstat.equalsIgnoreCase("Divorced")||mstat.equalsIgnoreCase("Widowed")))
				return true;
				else
				return false;
		}
	public boolean isValidGrade(String grade) {
		if((grade!=null)&&(grade.equalsIgnoreCase("M1")||grade.equalsIgnoreCase("M2")||grade.equalsIgnoreCase("M3")||grade.equalsIgnoreCase("M4")||grade.equalsIgnoreCase("M5")||grade.equalsIgnoreCase("M6")||grade.equalsIgnoreCase("M7")))
					return true;
					else
					return false;
			}
	public boolean isValidBasic(double basic) {
		String str=String.valueOf(basic);
		Pattern namePattern=Pattern.compile("^[1-9][0-9]*$");
		Matcher nameMatcher=namePattern.matcher(str);
		return nameMatcher.matches();
			}
	public boolean isValidBsalary(String grade,double basic) {
		boolean flag=false;
		if(grade.equals("M1"))
		{
			if(basic>=100000)
				flag=true;
		}
		else	if(grade.equals("M2"))
		{
			if(basic>=90000)
				flag=true;
		}
		else	if(grade.equals("M3"))
		{
			if(basic>=80000)
				flag=true;
		}
		else	if(grade.equals("M4"))
		{
			if(basic>=70000)
				flag=true;
		}
		else	if(grade.equals("M5"))
		{
			if(basic>=60000)
				flag=true;
		}
		else	if(grade.equals("M6"))
		{
			if(basic>=50000)
				flag=true;
		}
		else	if(grade.equals("M7"))
		{
			if(basic>=40000)
				flag=true;
		}
		return flag;
	}

	
		
}
