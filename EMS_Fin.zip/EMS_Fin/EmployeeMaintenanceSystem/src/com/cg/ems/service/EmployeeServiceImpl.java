package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.bean.LeaveBean;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDao dao = new EmployeeDaoImpl();
	
	@Override
	public Employee searchById(String id) throws EmployeeException {
		return dao.searchById(id);
	}

	@Override
	public List<Employee> searchByFN(String fName) throws EmployeeException {
		return dao.searchByFN(fName);
	}

	@Override
	public List<Employee> searchByLN(String lName) throws EmployeeException {
		return dao.searchByLN(lName);
	}

	@Override
	public List<Employee> searchByDepId(int dept) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.searchByDepId(dept);
	}

	@Override
	public List<Employee> searchByGrade(String grade) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.searchByGrade(grade);
	}

	@Override
	public List<Employee> searchByMarital(String marital)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.searchByMarital(marital);
	}

	@Override
	public int applyLeave(LeaveBean leave) throws EmployeeException {
		
		return dao.applyLeave(leave);
	}

	@Override
	public int approveLeave(String empId, String mgrId, int action)
			throws EmployeeException {
		return dao.approveLeave(empId, mgrId, action);
	}

	@Override
	public int approveOnThird(String empId) throws EmployeeException {
		
		return dao.approveOnThird(empId);
		
	}

	
}
