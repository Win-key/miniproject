package com.cg.ems.service;

import java.util.List;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;

public interface IAdminService {

	public int AddEmployee(Employee employee)throws EmployeeException;
	public int modifyEmployee(Employee employee)throws EmployeeException;
	public List<Employee> viewAllEmployees()throws EmployeeException;
	
}
