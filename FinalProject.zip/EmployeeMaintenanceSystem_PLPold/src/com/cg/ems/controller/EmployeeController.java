package com.cg.ems.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.ActionBean;
import com.cg.ems.entities.Employee;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IEmployeeService;

/*******************************************************************************************************
 * - Class Name   : AdminController
 * - Author 	  : Venkatesh Rajendran
 * - Creation Date: 13/02/2018 
 * - Description  : Executes employee functionalities
 ********************************************************************************************************/
@Controller
@RequestMapping(value = "*.emp")
public class EmployeeController {

	@Autowired
	IEmployeeService service;
	Logger logger = Logger.getLogger(EmployeeController.class);

	public EmployeeController() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping(value = "/applyLeaveForm")
	public ModelAndView applyLeaveForm(HttpServletRequest request) {

		LeaveBean leave = new LeaveBean();
		leave.setEmpId((String) request.getSession().getAttribute("id"));
		return new ModelAndView("applyLeave", "leave", leave);
	}

	@RequestMapping(value = "/applyLeave")
	public ModelAndView applyLeave(
			@ModelAttribute("leave") @Valid LeaveBean leave,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			try {
				// calculating the difference in terms of days
				long diff = leave.getDateTo().getTime()
						- leave.getDateFrom().getTime();
				int noofdaysApplied = (int) TimeUnit.DAYS.convert(diff,
						TimeUnit.MILLISECONDS);
				if (noofdaysApplied < 0) {
					// checking whether the number of days is greater than zero
					logger.info("Date from which you are applying leave is lesser than the date until when you have applied!");
					throw new EmployeeException(
							"Date from which you are applying leave cannot be lesser than the date until when you have applied!");
				}
				Employee bean = service.findEmployeeById(leave.getEmpId());
				if (bean != null) {
					// search the employee using employee id
					LeaveBean leaveBean = service.findLeaveById(leave
							.getEmpId());
					// if executes when employee is found
					if (leaveBean == null) {
						// add records to the leave_history table
						service.addLeave(leave);
						logger.info("Leave applied successfully!");
						mv = new ModelAndView("success", "message",
								"Leave applied successfully!");
					} // checking if the employee has already applied leave
					else {
						if (leaveBean.getApprovalStatus().equals("applied")) {
							logger.info(" Previous leave application is still in process!");
							mv = new ModelAndView("success", "message",
									"Your previous leave application is still in process!");
						} // executed when employee id exists in the table
						else {
							leaveBean.setDateFrom(leave.getDateFrom());
							leaveBean.setDateTo(leave.getDateTo());
							service.updateLeave(leaveBean);
							logger.info(" Leave applied successfully!");
							mv = new ModelAndView("success", "message",
									"Leave applied successfully!");
						}

					}

				} else {
					logger.info("Employee with the given id doesn't exist!");
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!!Employee with the given id doesn't exist!");
				}
			} catch (EmployeeException e) {
				logger.info(e.getMessage());
				mv = new ModelAndView("errorScreen", "message", "Sorry!! "
						+ e.getMessage());
				e.printStackTrace();
			}
		} else {
			mv = new ModelAndView("applyLeave", "leave", leave);
		}

		return mv;
	}

	@RequestMapping(value = "/approveLeaveForm")
	public ModelAndView approveLeaveForm() {
		ActionBean actionBean = new ActionBean();
		return new ModelAndView("approveLeave", "actionBean", actionBean);
	}

	@RequestMapping(value = "/approveLeave")
	public ModelAndView approveLeave(
			@ModelAttribute("actionBean") @Valid ActionBean actionBean,
			BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			try {
				// search the employee using employee id
				Employee bean = service.findEmployeeById(actionBean.getEmpId());
				if (bean != null) {
					LeaveBean leaveBean = service.findLeaveById(actionBean
							.getEmpId());
					//checking the leave history details of the employee
					if (leaveBean == null) {
						logger.info("The employee hasn't applied for leave!");
						mv = new ModelAndView("success", "message",
								"The employee hasn't applied for leave!");
					}//checking for all the employees whose status id applied
					else {
						if (leaveBean.getApprovalStatus().equals("applied")) {
							leaveBean.setApprovalStatus(actionBean.getAction());
							int count = service.approveLeave(leaveBean);
							//when manager decides to approve
							if (count == 1) {
								logger.info("Leave approved successfully!");
								mv = new ModelAndView("success", "message",
										"Leave approved successfully");
							} //when manager decides to reject
							else if (count == 0) {
								logger.info("Leave  has been rejected!");
								mv = new ModelAndView("success", "message",
										"Leave has been rejected!");
							}//when the employee has insufficient leave balance
							else {
								logger.info("Insufficient leave balance!");
								mv = new ModelAndView("success", "message",
										"Insufficient leave balance!");
							}

						} //when it is not more days since the manager has approved his leave
						else {
							logger.info("Action on this leave is already taken!");
							mv = new ModelAndView("success", "message",
									"Action on this leave is already taken!");
						}
					}
				} else {
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!! Employee with given id doesn't exist!");
				}
			} catch (EmployeeException e) {
				logger.info(e.getMessage());
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!!Employee leave could not be approved! "
								+ e.getMessage());

			}
		} else {
			mv = new ModelAndView("approveLeave", "actionBean", actionBean);
		}

		return mv;
	}

	@RequestMapping(value = "/viewbyidForm")
	public ModelAndView viewByIdForm() {
		//display the form 
		ModelAndView mv = new ModelAndView("viewByForm");
		mv.addObject("isId", true);
		return mv;
	}

	@RequestMapping(value = "/viewbyid")
	public ModelAndView viewbyid(@RequestParam("empId") String byId) {

		ModelAndView mv = null;
		try {
			//search the employee using employee id
			Employee employee = service.findEmployeeById(byId);
			List<Employee> list = new ArrayList<Employee>();
			list.add(employee);
			//if executed when the employee  does not exist
			if (employee == null) {
				mv = new ModelAndView("searchDisplay", "isThere", false);
				logger.info("No employee found with the given id!");
				mv.addObject("message", "No employee found with the given id!");
			} //else executed when the employee exists
			else {
				mv = new ModelAndView("searchDisplay", "list", list);
				mv.addObject("isThere", true);
			}
		}

		catch (EmployeeException e) {
			logger.info(e.getMessage());
			logger.info("Employee details could not be displayed!");
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

	@RequestMapping(value = "/viewbyfnameForm")
	public ModelAndView viewbyfnameForm() {
		ModelAndView mv = new ModelAndView("viewByForm");
		mv.addObject("isFname", true);
		return mv;
	}

	@RequestMapping(value = "/viewbyfname")
	public ModelAndView viewbyfname(@RequestParam("firstName") String firstName) {

		ModelAndView mv = null;

		try {
			//search the employee using employee first name
			List<Employee> list = service.findEmployeeByFName(firstName);
			//if executed when the employee  does not exist
			if (list.isEmpty()) {
				mv = new ModelAndView("searchDisplay", "isThere", false);
				logger.info("No employees found with the given first name!");
				mv.addObject("message",
						"No employees found with the given first name!");
			}//else executed when the employee exists
			else {
				mv = new ModelAndView("searchDisplay", "list", list);
				mv.addObject("isThere", true);
			}
		} catch (EmployeeException e) {
			logger.info(e.getMessage());
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

	@RequestMapping(value = "/viewbygradeForm")
	public ModelAndView viewbygradeForm() {
		ModelAndView mv = new ModelAndView("viewByForm");
		mv.addObject("isGrade", true);
		return mv;
	}

	@RequestMapping(value = "/viewbygrade")
	public ModelAndView viewbygrade(@RequestParam("grade") String grade) {

		ModelAndView mv = null;

		try {
			//search the employee using employee grade
			List<Employee> list = service.findEmployeeByGrade(grade);
			//if executed when the employee  does not exist
			if (list.isEmpty()) {
				mv = new ModelAndView("searchDisplay", "isThere", false);
				logger.info("No employees found with the given grade!");
				mv.addObject("message",
						"No employees found with the given grade!");
			}//else executed when the employee exists 
			else {
				logger.info("Records found in the database!");
				mv = new ModelAndView("searchDisplay", "list", list);
				mv.addObject("isThere", true);
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

	@RequestMapping(value = "/viewbylnameForm")
	public ModelAndView viewbylnameForm() {
		//setting the view to the form 
		ModelAndView mv = new ModelAndView("viewByForm");
		mv.addObject("isLname", true);
		return mv;
	}

	@RequestMapping(value = "/viewbylname")
	public ModelAndView viewbylname(@RequestParam("lastName") String lastName) {

		ModelAndView mv = null;

		try {
			//search the employee using employee last name
			List<Employee> list = service.findEmployeeByLname(lastName);
			//if executed when the employee  does not exist
			if (list.isEmpty()) {
				logger.info("No employees found with the given last name!");
				mv = new ModelAndView("searchDisplay", "isThere", false);
				mv.addObject("message",
						"No employees found with the given last name!");
			}//else executed when the employee exists 
			else {
				mv = new ModelAndView("searchDisplay", "list", list);
				mv.addObject("isThere", true);
			}
		} catch (EmployeeException e) {
			logger.info(e.getMessage());
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!!Employee details could not be displayed! "
							+ e.getMessage());

		}

		return mv;
	}

}
