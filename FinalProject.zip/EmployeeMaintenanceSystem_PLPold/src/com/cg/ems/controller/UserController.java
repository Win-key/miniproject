package com.cg.ems.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IUserService;


/*******************************************************************************************************
- Class Name	:	AdminController
- Author		:	Venkatesh Rajendran
- Creation Date	:	12/02/2018
- Description	:	Executes login functionalities
********************************************************************************************************/
@Controller
@RequestMapping(value="*.obj")
public class UserController {

	@Autowired
	private IUserService service;
	Logger logger=Logger.getLogger(UserController.class);
	
	public UserController(){
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public IUserService getService() {
		return service;
	}

	public void setService(IUserService service) {
		this.service = service;
	}

	@RequestMapping("/showHomeScreen")
	public String showHomeScreen() {
		return "homeScreen";
	}
	@RequestMapping("/showAdminScreen")
	public String showAdminScreen() {
		return "adminScreen";
	}
	@RequestMapping("/showEmpScreen")
	public String showEmpScreen() {
		return "employeeScreen";
	}
	@RequestMapping("/loginScreen")
	public ModelAndView loginScreen(@ModelAttribute("user") User user) {
		
		ModelAndView mv = new ModelAndView("loginScreen", "user", user);
		return mv;
	}

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute("user")@Valid User user, BindingResult result,HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		
		if (!result.hasErrors()) {
			try {

				String userName = user.getUserName();
				String userPassword = user.getPassword();
				//search the user type based on the password and name given
				String userType = service.getRole(userName,userPassword);
				if (userType != null) {
					
					//storing the attribute id in session
					request.getSession().setAttribute("id", user.getUserName());
					
					//executes if the user is admin
					if (userType.equals("admin")) {
						logger.info("User logged as admin!");
						mv.setViewName("adminScreen");
					}//executes if the user is employee
					else if(userType.equals("employee")) {
						logger.info("User logged as employee!");
						mv.setViewName("employeeScreen");
						mv.addObject("isMgr", false);
					}//executes if the user has entered wrong credentials
					else {
						logger.info("Wrong credentials entered by the user!");
						mv.setViewName("employeeScreen");
						mv.addObject("isMgr", true);
					}

				}
			} catch (EmployeeException e) {
				logger.info(e.getMessage());
				mv.setViewName("loginScreen");
				mv.addObject("error", e.getMessage());
			}
		}else{
			mv.setViewName("loginScreen");
			mv.addObject("user", user);
		}
		
		
		return mv;
	}
	
@RequestMapping(value="/logOut")
	
	public ModelAndView logOut(@ModelAttribute("user") User user) {
		ModelAndView mv = new ModelAndView("loginScreen", "user", user);
				return mv;
	}

}
