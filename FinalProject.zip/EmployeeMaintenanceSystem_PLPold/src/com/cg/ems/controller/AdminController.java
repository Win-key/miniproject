package com.cg.ems.controller;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IAdminService;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/*******************************************************************************************************
 * - Class Name : AdminController 
 * - Author : Shruti KrishnaMurthy 
 * - Creation Date : 13/02/2018 
 * - Description : Executes administrator functionalities
 ********************************************************************************************************/

@Controller
@RequestMapping(value = "*.adm")
public class AdminController {

	@Autowired
	private IAdminService service;
	Logger logger = Logger.getLogger(AdminController.class);

	public AdminController() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	public IAdminService getService() {
		return service;
	}

	public void setService(IAdminService service) {
		this.service = service;
	}

	@RequestMapping(value = "/addEmployeeForm")
	public ModelAndView addEmployeeForm() {
		Employee employee = new Employee();
		return new ModelAndView("addEmployee", "employee", employee);
	}

	@RequestMapping(value = "/addEmployee")
	public ModelAndView addEmployee(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try {
				// calculating the difference in terms of days
				long diff = employee.getEmpDateOfJoining().getTime()
						- employee.getEmpDateOfBirth().getTime();
				int daysDiff = (int) TimeUnit.DAYS.convert(diff,
						TimeUnit.MILLISECONDS);
				// convert to number of years
				int yearDif = daysDiff / 365;

				// check if the employee is aged between 18 and 60 years
				if (yearDif < 18 || yearDif > 60) {
					logger.info("Employee age should be greater than 18 and less than 60!");
					throw new EmployeeException(
							"Employee age should be greater than 18 and less than 60!");
				}

				// check if the employee already exist
				Employee bean = service.findEmployeeById(employee);

				// add employee if the find fails
				if (bean == null) {
					Employee employee1 = service.findManagerById(employee
							.getManagerId());
					if (employee1 != null) {
						// calling the add employee function
						service.addEmployee(employee);
						mv = new ModelAndView();
						mv.setViewName("success");
						logger.info("Employee details added successfully!");
						mv.addObject("message",
								"Employee details added successfully!");
						mv.addObject("employee", employee);

					}
					// executes when manager with the id given doesn't exist
					else {
						logger.info("Manager with the given Id does not exist!");
						mv = new ModelAndView("errorScreen", "message",
								"Sorry!Manager with the given Id does not exist!");
					}
				}
				// executes when employee with the id given already exists
				else {
					logger.info("Employee with the given Id already exist!");
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!An employee with the same Id already exist!");
				}
			} catch (EmployeeException e) {
				logger.info(e.getMessage());
				mv = new ModelAndView("errorScreen", "message",
						"Could not add the employee details!!" + e.getMessage());
			}
		} else {
			mv = new ModelAndView("addEmployee", "employee", employee);
		}

		return mv;

	}

	@RequestMapping(value = "/modifyEmployee")
	public ModelAndView modifyEmployee() {
		Employee employee = new Employee();
		return new ModelAndView("modifyScreen", "employee", employee);
	}

	@RequestMapping(value = "/modifyEmployeeId")
	public ModelAndView modifyEmployeeId(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			// find the employee with the given id
			Employee employee1 = service.findEmployeeById(employee);
			if (employee1 != null) {

				mv.setViewName("modifyById");
				mv.addObject("employee", employee1);
			}
			// else executes if the employee doesn't exist
			else {
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details could not be modified!");
			}
		} catch (EmployeeException e) {
			logger.info(e.getMessage());
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be modified!");
		}
		return mv;

	}

	@RequestMapping(value = "/modify")
	public ModelAndView modify(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (!result.hasErrors()) {
			try {

				long diff = employee.getEmpDateOfJoining().getTime()
						- employee.getEmpDateOfBirth().getTime();
				int daysDiff = (int) TimeUnit.DAYS.convert(diff,
						TimeUnit.MILLISECONDS);
				int yearDif = daysDiff / 365;
				//check if the age is between 18 and 60
				if (yearDif < 18 || yearDif > 60) {
					throw new EmployeeException(
							"Employee age should be greater than 18 and less than 60!");
				}
				//find the employee by passing the employee bean
				Employee employeeObj = service.modifyEmployee(employee);
				if (employeeObj != null) {
					//modified if the employee exists
					mv.setViewName("success");
					mv.addObject("employee", employeeObj);
					logger.info("Employee details modified successfully!");
					mv.addObject("message",
							"Employee details modified successfully!");
				} //second if closes here
				else {
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!Employee details could not be modified!");
				}
			} catch (EmployeeException e) {
				logger.info(e.getMessage());
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details could not be modified!"
								+ e.getMessage());
			}
		}//else executed when binding result object has errors
		else {
			mv.setViewName("modifyById");
			mv.addObject("employee", employee);
		}
		return mv;

	}

	@RequestMapping(value = "/displayAllEmployees")
	public ModelAndView displayAllEmployees(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			//calling the view all function 
			List<Employee> list = service.viewAllEmployees();
			//if executed when records are found in database
			if (!list.isEmpty()) {
				logger.info("Records found in the database!");
				mv.setViewName("displayScreen");
				mv.addObject("list", list);
			}//else executed when records are not found in database
			else {
				logger.info("No Records found in the database!");
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details could not be found!");
			}
		} catch (EmployeeException e) {
			logger.info(e.getMessage());
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details could not be found!");
		}
		return mv;

	}

}
