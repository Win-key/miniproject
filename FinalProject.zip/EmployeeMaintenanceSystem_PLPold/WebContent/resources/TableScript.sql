
CREATE TABLE user_masters(
	username  VARCHAR(15) PRIMARY KEY,
	password  VARCHAR(50) NOT NULL,
	userid VARCHAR2(6) NOT NULL,
	usertype VARCHAR(10) NOT NULL
);


INSERT INTO user_masters VALUES('admin','admin123','a1','admin');
INSERT INTO user_masters VALUES('e101','e@101','e1','employee');
INSERT INTO user_masters VALUES('e102','e@102','e2','employee');
INSERT INTO user_masters VALUES('e103','e@103','e3','employee');
INSERT INTO user_masters VALUES('e104','e@104','e4','employee');
INSERT INTO user_masters VALUES('e105','e@105','e5','employee');
INSERT INTO user_masters VALUES('e106','e@106','e6','employee');
INSERT INTO user_masters VALUES('e107','e@107','e7','employee');
INSERT INTO user_masters VALUES('e108','e@108','e8','employee');
INSERT INTO user_masters VALUES('e109','e@109','e9','employee');
INSERT INTO user_masters VALUES('e110','e@110','e10','employee');
INSERT INTO user_masters VALUES('m101','m@101','m1','manager');
INSERT INTO user_masters VALUES('m102','m@102','m2','manager');
INSERT INTO user_masters VALUES('m103','m@103','m3','manager');


CREATE TABLE departments(
	Dept_ID NUMBER(5) PRIMARY KEY,
	Dept_Name VARCHAR2(50)
);

INSERT INTO departments VALUES(1,'sales');
INSERT INTO departments VALUES(2,'finance');
INSERT INTO departments VALUES(3,'development');
INSERT INTO departments VALUES(4,'hr');

//dont create manager table
//CREATE TABLE manager (
	Mgr_Id varchar2(6) PRIMARY KEY,
	Mgr_Name varchar2(30),
	Dept_ID NUMBER(5) references department(Dept_ID));

INSERT INTO manager VALUES('m101','Shruti',1);
INSERT INTO manager VALUES('m102','Tejaswini',2);
INSERT INTO manager VALUES('m103','Venkatesh',3);//

CREATE TABLE employees(
	Emp_ID VARCHAR2(6) PRIMARY KEY,
	Emp_First_Name VARCHAR2(25), 
	Emp_Last_Name VARCHAR2(25),
	Emp_Date_of_Birth DATE, 
	Emp_Date_of_Joining DATE, 
	Emp_Dept_ID NUMBER(5) references departments(Dept_ID), 
	Emp_Grade VARCHAR2(2), 
	Emp_Designation VARCHAR2(50), 
	Emp_Basic NUMBER(8,2), 
	Emp_Gender VARCHAR2(1), 
	Emp_Marital_Status VARCHAR2(10), 
	Emp_Home_Address VARCHAR2(100), 
	Emp_Contact_Num VARCHAR2(15), 
	Mgr_Id varchar2(6) references employees(emp_ID)
);

INSERT INTO employees VALUES('e101','Bhanu','Choudary','03-FEB-96','03-FEB-18',1,'M1','Developer',20000.00,'F','Single','Bangalore','9965448402','m101');
INSERT INTO employees VALUES('e102','Priya','Sharma','03-JAN-95','18-AUG-18',2,'M1','Accountant',30000.00,'F','Married','10,MG road, Chennai','9900447702','m101');
INSERT INTO employees VALUES('e103','Rohit','Sharma','03-FEB-96','17-AUG-18',3,'M2','Clerk',30500.00,'M','Single','10,india gate, Mumbai','9600462200','m102');
INSERT INTO employees VALUES('e104','Nithish','Nair','03-JAN-96','15-JAN-18',4,'M1','Testing',40000.00,'F','Single','10,indra nagar, Luknow','9612462200','m102');
INSERT INTO employees VALUES('e105','MS','Dhoni','07-FEB-96','18-AUG-18',1,'M4','Developer',50000.00,'M','Married','10,Dhoni nagar, Ranji','8844461200','m103');
INSERT INTO employees VALUES('e106','Suresh','Raina','09-FEB-96','20-AUG-18',2,'M3','Consultant',400000.00,'M','Married','10,Anna nagar, Chennai','8832451288','m103');
INSERT INTO employees VALUES('m101','Shruti','Raju','16-FEB-96','29-AUG-18',3,'M1','Manager',95000.00,'F','Single','10,MG Road, Bangalore','7632455588','m101');
INSERT INTO employees VALUES('m102','Hardik','Pandiya','16-FEB-96','29-AUG-18',2,'M3','Manager',67000.00,'M','Single','14,Briyani Road, Mumbai','9332345588','m101');
INSERT INTO employees VALUES('m103','Virat','Kohli','10-FEB-96','20-AUG-18',3,'M2','Manager',88000.00,'M','Married','18,Electronic Road, Delhi','7896541230','m101');



CREATE SEQUENCE leave_seq START WITH 1000;

Leave_Id number, Emp_id  foreign key references employees(emp_id), leave_balance number check (leave_balance>=0), noofdays_applied number, date_from date, date_to date, status varchar2(20) check (status in ('applied','approved','rejected'))
CREATE TABLE leave_history(
	Leave_Id number,
	Emp_id varchar2(6) references employees(Emp_ID),
	leave_balance number check (leave_balance>=0),
	noofdays_applied number,
	date_from date, 
	date_to date,
	status varchar2(20) check (status in ('applied','approved','rejected')),
	date_of_app date
);
