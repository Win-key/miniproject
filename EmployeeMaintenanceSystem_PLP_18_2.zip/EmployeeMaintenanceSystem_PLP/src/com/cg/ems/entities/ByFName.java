package com.cg.ems.entities;

public class ByFName {

}
