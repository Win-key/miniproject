package com.cg.ems.dao;

import com.cg.ems.entities.Employee;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDao {

	public Employee findEmployeeById(String empId)throws EmployeeException;
	public LeaveBean findLeaveById(String empId) throws EmployeeException;
	public void addLeave(LeaveBean leave) throws EmployeeException;
	public void updateLeave(LeaveBean leave) throws EmployeeException;
	public void approveLeave(LeaveBean leave) throws EmployeeException;
	
}
