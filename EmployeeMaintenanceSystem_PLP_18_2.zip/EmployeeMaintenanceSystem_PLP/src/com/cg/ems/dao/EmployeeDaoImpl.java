package com.cg.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ems.entities.Employee;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Employee findEmployeeById(String empId)
			throws EmployeeException {
		Employee emp=entityManager.find(Employee.class, empId);
		return emp;
	}

	@Override
	public LeaveBean findLeaveById(String empId) throws EmployeeException {
		
		LeaveBean leave = null;
		String qry = "SELECT leave FROM LeaveBean leave WHERE leave.empId='" + empId+"'";
		TypedQuery<LeaveBean> query = entityManager.createQuery(qry, LeaveBean.class);
		List<LeaveBean> list = query.getResultList();
		if (!list.isEmpty()) {
			leave = list.get(0);
		}
		return leave;
	}

	@Override
	public void addLeave(LeaveBean leave) throws EmployeeException {
		
		entityManager.persist(leave);
		entityManager.flush();
		
	}

	@Override
	public void updateLeave(LeaveBean leave) throws EmployeeException {
		
		entityManager.merge(leave);
		entityManager.flush();
	}

	@Override
	public void approveLeave(LeaveBean leave) throws EmployeeException {

		entityManager.merge(leave);
		entityManager.flush();
		
	}
	
}
