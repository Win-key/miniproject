package com.cg.ems.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ems.entities.User;
import com.cg.ems.exception.EmployeeException;

@Repository
@Transactional
public class UserDaoImpl implements IUserDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public User getUserByName(String name) throws EmployeeException {
		return entityManager.find(User.class,name);
		
	}

}
