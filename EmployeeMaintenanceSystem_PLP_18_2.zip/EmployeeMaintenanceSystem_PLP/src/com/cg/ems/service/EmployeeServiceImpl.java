package com.cg.ems.service;

import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.entities.Employee;
import com.cg.ems.entities.LeaveBean;
import com.cg.ems.exception.EmployeeException;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao dao;

	public IEmployeeDao getDao() {
		return dao;
	}

	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Employee findEmployeeById(String empId)
			throws EmployeeException {
		
		return dao.findEmployeeById(empId);
	}

	@Override
	public LeaveBean findLeaveById(String empId) throws EmployeeException {
		return dao.findLeaveById(empId);
	}

	@Override
	public void addLeave(LeaveBean leave) throws EmployeeException {
		
		leave.setLeaveBalance(12);
		long diff = leave.getDateTo().getTime() - leave.getDateFrom().getTime();
		int noofdaysApplied = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		noofdaysApplied += 1;
		leave.setNoofdaysApplied(noofdaysApplied);
		leave.setApprovalStatus("applied");
		
		dao.addLeave(leave);
		
	}

	@Override
	public void updateLeave(LeaveBean leave) throws EmployeeException {
		
		long diff = leave.getDateTo().getTime() - leave.getDateFrom().getTime();
		int noofdaysApplied = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		noofdaysApplied += 1;
		leave.setNoofdaysApplied(noofdaysApplied);
		leave.setApprovalStatus("applied");
		
		dao.updateLeave(leave);
		
	}

	@Override
	public int approveLeave(LeaveBean leave) throws EmployeeException {
		int count = 0;
		int noOfLeaves = leave.getNoofdaysApplied();
		int leaveBal = leave.getLeaveBalance();
		leaveBal = leaveBal - noOfLeaves;
		if (leaveBal<0) {
			throw new EmployeeException("Insufficient leaves");
		}else{
		dao.approveLeave(leave);
		if (leave.getApprovalStatus().equals("approved")) {
			leave.setLeaveBalance(leaveBal);
			count = 1;
			}
		}
		return count;
	}
	
}
