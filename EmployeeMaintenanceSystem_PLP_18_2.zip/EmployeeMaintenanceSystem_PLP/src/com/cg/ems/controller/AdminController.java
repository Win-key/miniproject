package com.cg.ems.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.entities.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.IAdminService;

@Controller
@RequestMapping(value = "*.adm")
public class AdminController {

	@Autowired
	private IAdminService service;

	public IAdminService getService() {
		return service;
	}

	public void setService(IAdminService service) {
		this.service = service;
	}

	@RequestMapping(value = "/addEmployeeForm")
	public ModelAndView addEmployeeForm() {
		Employee employee = new Employee();
		return new ModelAndView("addEmployee", "employee", employee);
	}

	@RequestMapping(value = "/addEmployee")
	public ModelAndView addEmployee(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try {
				Employee bean = service.findEmployeeById(employee);
				if (bean != null) {
					service.addEmployee(employee);
					mv = new ModelAndView();
					mv.setViewName("success");
					mv.addObject("message", "Added successfully");
					mv.addObject("employee", employee);

				} else {
					mv = new ModelAndView("errorScreen", "message",
							"Sorry!Employee with the same Id already exist!");
				}
			} catch (EmployeeException e) {
				mv = new ModelAndView("errorScreen", "message", "Add Failure");
			}
		} else {
			mv = new ModelAndView("addEmployee", "employee", employee);
		}

		return mv;

	}

	@RequestMapping(value = "/modifyEmployee")
	public ModelAndView modifyEmployee(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("modifyScreen");
		mv.addObject("employee",employee);
		return mv;
	}
	
	@RequestMapping(value = "/modifyEmployeeId")
	public ModelAndView modifyEmployeeId(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			employee = service.findEmployeeById(employee);
			if (employee!=null) {
				mv.setViewName("modifyById");
				mv.addObject("employee",employee);
			}
 else {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details couldnt be modified!");
}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details couldnt be modified!");
		}
		return mv;
		
	}
	
	/*@RequestMapping(value="/modify")
	public String modify(){
		return "success";
	}*/
	@RequestMapping(value="/modify")
	public ModelAndView modify(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		Employee bean=null;
		try {
			bean=service.modifyEmployee(employee);
			
			if(bean!=null){
				//System.out.println(bean);
			mv.setViewName("success");
			mv.addObject("employee",bean);
			mv.addObject("message", "inside modify");
			}
			else
			{
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details couldnt be modifieddddddddd!");
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Employee details couldnt be modifieddddddddd!");
		}
		return mv;
	
	}
	
	@RequestMapping(value="/displayAllEmployees")
	public ModelAndView displayAllEmployees(
			@ModelAttribute("employee") Employee employee) {
		ModelAndView mv = new ModelAndView();
		try {
			List<Employee> list=service.viewAllEmployees();
			if(!list.isEmpty()){
			mv.setViewName("displayScreen");
			mv.addObject("list", list);
			}
			else{
				mv = new ModelAndView("errorScreen", "message",
						"Sorry!Employee details couldnt be found!");
			}
		} catch (EmployeeException e) {
			mv = new ModelAndView("errorScreen", "message",
					"Sorry!Employee details couldnt be found!");
		}
		return mv;
	
	}
}

