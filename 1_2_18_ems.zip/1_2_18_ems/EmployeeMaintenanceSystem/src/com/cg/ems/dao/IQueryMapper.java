package com.cg.ems.dao;

public interface IQueryMapper {
	
	public static final String SELECT_USER_BYNAME = "SELECT username,password,userid,usertype FROM user_master WHERE username=?";
	
}
