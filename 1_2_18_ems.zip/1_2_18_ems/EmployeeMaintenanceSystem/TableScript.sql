CREATE TABLE user_master(
	username  VARCHAR(15) PRIMARY KEY,
	password  VARCHAR(50) NOT NULL,
	userid VARCHAR2(6) NOT NULL,
	usertype VARCHAR(10) NOT NULL
);



INSERT INTO user_master (username,password,userid,usertype) VALUES('admin','admin123','a1','admin');
INSERT INTO user_master VALUES('emp1','emp123','e1','employee');