package com.cg.ems.pl;




import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.IAdminService;

public class AdminConsole {

	private IAdminService aService=new AdminServiceImpl();
	private String userName;
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
	Date date;

	public AdminConsole(String userName) {
		
		this.userName = userName;
	}
	
	
	public void start()
	{
		System.out.println("Welcome " + userName);
		Scanner scanner=new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Add the employee");
			System.out.println("2.Update the Employee details");
			System.out.println("3.View all employees");
			System.out.println("4.exit");
			System.out.println("Enter the choice");
			int choice=scanner.nextInt();scanner.nextLine();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the employee details");
				System.out.println("Enter the unique employee id");
				String empId=scanner.nextLine();
				System.out.println("Enter the employee First Name");
				String firstName = scanner.nextLine();
				System.out.println("Enter the employee last name");
				String lastName = scanner.nextLine();

				System.out.println("Enter the employee date of birth");
				String date = scanner.next();

				System.out.println("Enter the employee date of joining");
				String joinDate = scanner.next();
				try {
					DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
					Date dateofBirth = d.parse(date);
					Date dateofJoining = d.parse(joinDate);

					System.out.println("Enter the department id");
					int deptId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter the grade");
					String grade = scanner.nextLine();
					System.out.println("Enter the designation");
					String designation = scanner.nextLine();
					System.out.println("Enter the Basic salary");
					double basic = scanner.nextDouble();
					scanner.nextLine();
					System.out.println("Enter the gender");
					String gender = scanner.nextLine();
					System.out.println("Enter the marital status");
					String status = scanner.nextLine();
					System.out.println("enter the address");
					String address = scanner.nextLine();
					System.out.println("Enter the employee number");
					String number = scanner.nextLine();
					System.out.println("Enter the manager id");
					String managerId = scanner.nextLine();

					Employee emp = new Employee();
					emp.setEmpID(empId);
					emp.setEmpFirstName(firstName);
					emp.setEmpLastName(lastName);
					emp.setEmpDateOfBirth(dateofBirth);
					emp.setEmpDateOfJoining(dateofJoining);
					emp.setEmpDeptId(deptId);
					emp.setEmpGrade(grade);
					emp.setEmpDesignation(designation);
					emp.setEmpBasic(basic);
					emp.setEmpGender(gender);
					emp.setEmpMaritalStatus(status);
					emp.setEmpHomeAddress(address);
					emp.setEmpContactNum(number);
					emp.setManagerId(managerId);
				
					int result=aService.AddEmployee(emp);
					if(result>0)
					{
						System.out.println("Successfull!!");
					}
					else
					{
						System.out.println("Failed!!");
					}
				} catch (EmployeeException e) {
					System.out.println("Add Failed"+e.getMessage());
				} catch (ParseException e) {
					System.out.println("please enter the date in the required format");
				}
			break;
			case 2:
				System.out.println("Enter the employee details");
				System.out.println("Enter the unique employee id");
				String employeeId=scanner.nextLine();
				System.out.println("Enter the employee First Name");
				String fName = scanner.nextLine();
				System.out.println("Enter the employee last name");
				String lName = scanner.nextLine();

				System.out.println("Enter the employee date of birth");
				String birthDate = scanner.next();

				System.out.println("Enter the employee date of joining");
				String joinDate2 = scanner.next();
				try {
					DateFormat d = new SimpleDateFormat("dd-MM-yyyy");
					Date dateofBirth = d.parse(birthDate);
					Date dateofJoining = d.parse(joinDate2);

					System.out.println("Enter the department id");
					int deptId = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter the grade");
					String grade = scanner.nextLine();
					System.out.println("Enter the designation");
					String designation = scanner.nextLine();
					System.out.println("Enter the Basic salary");
					double basic = scanner.nextDouble();
					scanner.nextLine();
					System.out.println("Enter the gender");
					String gender = scanner.nextLine();
					System.out.println("Enter the marital status");
					String status = scanner.nextLine();
					System.out.println("enter the address");
					String address = scanner.nextLine();
					System.out.println("Enter the employee number");
					String number = scanner.nextLine();
					System.out.println("Enter the manager id");
					String managerId = scanner.nextLine();

					Employee emp = new Employee();
					emp.setEmpID(employeeId);
					emp.setEmpFirstName(fName);
					emp.setEmpLastName(lName);
					emp.setEmpDateOfBirth(dateofBirth);
					emp.setEmpDateOfJoining(dateofJoining);
					emp.setEmpDeptId(deptId);
					emp.setEmpGrade(grade);
					emp.setEmpDesignation(designation);
					emp.setEmpBasic(basic);
					emp.setEmpGender(gender);
					emp.setEmpMaritalStatus(status);
					emp.setEmpHomeAddress(address);
					emp.setEmpContactNum(number);
					emp.setManagerId(managerId);
				
					int result=aService.modifyEmployee(emp);
					if(result>0)
					{
						System.out.println("Successfull!!");
					}
					else
					{
						System.out.println("Failed!!");
					}
				} catch (EmployeeException e) {
					System.out.println("Add Failed"+e.getMessage());
				} catch (ParseException e) {
					System.out.println("please enter the date in the required format");
				}
				break;
			case 3:
				List<Employee> list= new ArrayList<Employee>();
				try {
					list=aService.viewAllEmployees();
					if(!list.isEmpty())
					{
						for(Employee emp:list)
						{
							System.out.println(emp.getEmpID()+" "+emp.getEmpFirstName()+" "+emp.getEmpLastName()+emp.getEmpDeptId()+" "+emp.getEmpGrade()+" "+emp.getEmpDesignation()+" ");
						}
					}
				} catch (EmployeeException e) {
					System.out.println("Employees not found !!"+e.getMessage());
				}
				break;
				
			case 4:
				scanner.close();
				System.exit(0);
			break;
			}
			
			
			
			
		}
			
		
	}
	
	
	
}
