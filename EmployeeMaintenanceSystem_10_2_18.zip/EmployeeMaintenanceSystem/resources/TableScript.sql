CREATE TABLE user_master(
	username  VARCHAR(15) PRIMARY KEY,
	password  VARCHAR(50) NOT NULL,
	userid VARCHAR2(6) NOT NULL,
	usertype VARCHAR(10) NOT NULL
);


INSERT INTO user_master VALUES('admin','admin123','a1','admin');
INSERT INTO user_master VALUES('emp1','emp123','e1','employee');


CREATE TABLE department(
	Dept_ID NUMBER(5) PRIMARY KEY,
	Dept_Name VARCHAR2(50)
);

INSERT INTO department VALUES(1,'sales');
INSERT INTO department VALUES(2,'finance');
INSERT INTO department VALUES(3,'development');
INSERT INTO department VALUES(4,'hr');

//dont create manager table
//CREATE TABLE manager (
	Mgr_Id varchar2(6) PRIMARY KEY,
	Mgr_Name varchar2(30),
	Dept_ID NUMBER(5) references department(Dept_ID));

INSERT INTO manager VALUES('m101','Shruti',1);
INSERT INTO manager VALUES('m102','Tejaswini',2);
INSERT INTO manager VALUES('m103','Venkatesh',3);//

CREATE TABLE employee(
	Emp_ID VARCHAR2(6) PRIMARY KEY,
	Emp_First_Name VARCHAR2(25), 
	Emp_Last_Name VARCHAR2(25),
	Emp_Date_of_Birth DATE, 
	Emp_Date_of_Joining DATE, 
	Emp_Dept_ID NUMBER(5) references department(Dept_ID), 
	Emp_Grade VARCHAR2(2), 
	Emp_Designation VARCHAR2(50), 
	Emp_Basic NUMBER(8,2), 
	Emp_Gender VARCHAR2(1), 
	Emp_Marital_Status VARCHAR2(10), 
	Emp_Home_Address VARCHAR2(100), 
	Emp_Contact_Num VARCHAR2(15), 
	Mgr_Id varchar2(6) references employee(emp_ID)
);

INSERT INTO employee VALUES('e101','Bhanu','Choudary','03-FEB-96','03-FEB-18',1,'M1','Manager',20000.00,'F','Single','Bangalore','9965448402','e101');
INSERT INTO employee VALUES('e102','Priya','Sharma','03-JAN-95','18-AUG-18',2,'M1','Accountant',30000.00,'F','Married','10,MG road, Chennai','9900447702','e101');

CREATE SEQUENCE leave_seq START WITH 1000;

Leave_Id number, Emp_id  foreign key references employee(emp_id), leave_balance number check (leave_balance>=0), noofdays_applied number, date_from date, date_to date, status varchar2(20) check (status in ('applied','approved','rejected'))
CREATE TABLE leave_history(
	Leave_Id number,
	Emp_id varchar2(6) references employee(Emp_ID),
	leave_balance number check (leave_balance>=0),
	noofdays_applied number,
	date_from date, 
	date_to date,
	status varchar2(20) check (status in ('applied','approved','rejected')),
	date_of_app date
);
